"""
Stack Overflow Data Collector for Candidate Sourcing AI Module

This module handles the integration with Stack Overflow API to collect developer data.
It includes reputation analysis, answer quality assessment, and expertise identification.
"""

import os
import json
import logging
import requests
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class StackOverflowDataCollector:
    """
    Stack Overflow Data Collector class for retrieving and processing developer data.
    """
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize the Stack Overflow Data Collector with API key.
        
        Args:
            api_key: Stack Overflow API key for authentication (optional)
        """
        self.api_key = api_key or os.environ.get('STACKOVERFLOW_API_KEY')
        self.base_url = "https://api.stackexchange.com/2.3"
        self.headers = {
            "Accept": "application/json"
        }
        
        logger.info("Stack Overflow Data Collector initialized")
    
    def _make_request(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Make a request to the Stack Overflow API.
        
        Args:
            endpoint: API endpoint to call
            params: Query parameters
            
        Returns:
            API response as dictionary
        """
        url = f"{self.base_url}/{endpoint}"
        
        # Add API key to parameters if available
        request_params = params or {}
        if self.api_key:
            request_params["key"] = self.api_key
        
        # Add default parameters
        request_params["site"] = request_params.get("site", "stackoverflow")
        
        try:
            response = requests.get(url, headers=self.headers, params=request_params)
            response.raise_for_status()
            return {"success": True, "data": response.json()}
        except requests.exceptions.RequestException as e:
            logger.error(f"Stack Overflow API request failed: {str(e)}")
            return {"success": False, "message": str(e), "data": {}}
    
    def search_users(self, 
                    query: str, 
                    tag: Optional[str] = None,
                    sort: str = "reputation",
                    order: str = "desc",
                    page_size: int = 30,
                    page: int = 1) -> Dict[str, Any]:
        """
        Search for Stack Overflow users based on provided criteria.
        
        Args:
            query: Search query string
            tag: Filter by tag
            sort: Sort field (reputation, creation, name, modified)
            order: Sort order (asc, desc)
            page_size: Results per page (max 100)
            page: Page number
            
        Returns:
            Dictionary containing search results
        """
        logger.info(f"Searching Stack Overflow users with query: {query}")
        
        params = {
            "inname": query,
            "sort": sort,
            "order": order,
            "pagesize": page_size,
            "page": page
        }
        
        if tag:
            params["tagged"] = tag
        
        return self._make_request("users", params)
    
    def get_user_profile(self, user_id: int) -> Dict[str, Any]:
        """
        Retrieve detailed profile information for a Stack Overflow user.
        
        Args:
            user_id: Stack Overflow user ID
            
        Returns:
            Dictionary containing user profile data
        """
        logger.info(f"Retrieving profile for Stack Overflow user: {user_id}")
        return self._make_request(f"users/{user_id}")
    
    def get_user_top_tags(self, user_id: int) -> Dict[str, Any]:
        """
        Retrieve top tags for a Stack Overflow user.
        
        Args:
            user_id: Stack Overflow user ID
            
        Returns:
            Dictionary containing user's top tags
        """
        logger.info(f"Retrieving top tags for Stack Overflow user: {user_id}")
        return self._make_request(f"users/{user_id}/top-tags")
    
    def get_user_answers(self, 
                        user_id: int, 
                        sort: str = "votes",
                        order: str = "desc",
                        page_size: int = 30,
                        page: int = 1) -> Dict[str, Any]:
        """
        Retrieve answers posted by a Stack Overflow user.
        
        Args:
            user_id: Stack Overflow user ID
            sort: Sort field (activity, creation, votes)
            order: Sort order (asc, desc)
            page_size: Results per page (max 100)
            page: Page number
            
        Returns:
            Dictionary containing user's answers
        """
        logger.info(f"Retrieving answers for Stack Overflow user: {user_id}")
        
        params = {
            "sort": sort,
            "order": order,
            "pagesize": page_size,
            "page": page,
            "filter": "withbody"  # Include the answer body
        }
        
        return self._make_request(f"users/{user_id}/answers", params)
    
    def get_user_questions(self, 
                          user_id: int, 
                          sort: str = "votes",
                          order: str = "desc",
                          page_size: int = 30,
                          page: int = 1) -> Dict[str, Any]:
        """
        Retrieve questions posted by a Stack Overflow user.
        
        Args:
            user_id: Stack Overflow user ID
            sort: Sort field (activity, creation, votes)
            order: Sort order (asc, desc)
            page_size: Results per page (max 100)
            page: Page number
            
        Returns:
            Dictionary containing user's questions
        """
        logger.info(f"Retrieving questions for Stack Overflow user: {user_id}")
        
        params = {
            "sort": sort,
            "order": order,
            "pagesize": page_size,
            "page": page,
            "filter": "withbody"  # Include the question body
        }
        
        return self._make_request(f"users/{user_id}/questions", params)
    
    def analyze_developer_expertise(self, user_id: int) -> Dict[str, Any]:
        """
        Analyze a developer's expertise based on their Stack Overflow activity.
        
        Args:
            user_id: Stack Overflow user ID
            
        Returns:
            Dictionary containing expertise analysis
        """
        logger.info(f"Analyzing expertise for Stack Overflow user: {user_id}")
        
        # Get user profile
        profile_result = self.get_user_profile(user_id)
        if not profile_result.get("success"):
            return {"success": False, "message": "Failed to retrieve user profile", "data": {}}
        
        profile = profile_result.get("data", {}).get("items", [])[0] if profile_result.get("data", {}).get("items") else {}
        
        # Get user's top tags
        tags_result = self.get_user_top_tags(user_id)
        top_tags = tags_result.get("data", {}).get("items", []) if tags_result.get("success") else []
        
        # Get user's top answers
        answers_result = self.get_user_answers(user_id, page_size=50)
        top_answers = answers_result.get("data", {}).get("items", []) if answers_result.get("success") else []
        
        # Calculate expertise metrics
        reputation = profile.get("reputation", 0)
        answer_count = profile.get("answer_count", 0)
        question_count = profile.get("question_count", 0)
        accept_rate = profile.get("accept_rate", 0)
        
        # Calculate average score of answers
        total_score = sum(answer.get("score", 0) for answer in top_answers)
        avg_answer_score = total_score / len(top_answers) if top_answers else 0
        
        # Determine expertise level
        if reputation >= 20000:
            expertise_level = "Expert"
        elif reputation >= 5000:
            expertise_level = "Advanced"
        elif reputation >= 1000:
            expertise_level = "Intermediate"
        else:
            expertise_level = "Beginner"
        
        # Prepare expertise analysis result
        expertise_analysis = {
            "stackoverflow_user_id": user_id,
            "profile_url": f"https://stackoverflow.com/users/{user_id}",
            "display_name": profile.get("display_name"),
            "reputation": reputation,
            "gold_badges": profile.get("badge_counts", {}).get("gold", 0),
            "silver_badges": profile.get("badge_counts", {}).get("silver", 0),
            "bronze_badges": profile.get("badge_counts", {}).get("bronze", 0),
            "answer_count": answer_count,
            "question_count": question_count,
            "accept_rate": accept_rate,
            "avg_answer_score": avg_answer_score,
            "member_since": profile.get("creation_date"),
            "last_access": profile.get("last_access_date"),
            "location": profile.get("location"),
            "website_url": profile.get("website_url"),
            "about_me": profile.get("about_me"),
            "expertise_level": expertise_level,
            "top_tags": [
                {
                    "name": tag.get("tag_name"),
                    "score": tag.get("answer_score", 0),
                    "post_count": tag.get("answer_count", 0),
                    "expertise_level": "Expert" if tag.get("answer_score", 0) > 100 else 
                                      "Advanced" if tag.get("answer_score", 0) > 50 else 
                                      "Intermediate" if tag.get("answer_score", 0) > 20 else 
                                      "Beginner"
                }
                for tag in top_tags[:10]
            ],
            "top_answers": [
                {
                    "title": answer.get("title", ""),
                    "link": answer.get("link", ""),
                    "score": answer.get("score", 0),
                    "is_accepted": answer.get("is_accepted", False),
                    "tags": answer.get("tags", []),
                    "creation_date": answer.get("creation_date")
                }
                for answer in sorted(top_answers, key=lambda x: x.get("score", 0), reverse=True)[:5]
            ]
        }
        
        return {"success": True, "data": expertise_analysis}
    
    def search_tech_experts(self, 
                           tech_tags: List[str], 
                           min_reputation: int = 1000,
                           limit: int = 50) -> List[Dict[str, Any]]:
        """
        Search for technical experts in specific technologies.
        
        Args:
            tech_tags: List of technology tags to search for
            min_reputation: Minimum reputation score
            limit: Maximum number of experts to return
            
        Returns:
            List of expert dictionaries with expertise analysis
        """
        logger.info(f"Searching for experts in technologies: {', '.join(tech_tags)}")
        
        all_experts = []
        
        # Search for each tag separately to maximize results
        for tag in tech_tags:
            # Perform initial search
            page = 1
            while len(all_experts) < limit:
                results = self.search_users(
                    query="",  # Empty query to search all users
                    tag=tag,
                    sort="reputation",
                    order="desc",
                    page_size=30,
                    page=page
                )
                
                if not results.get("success"):
                    logger.error(f"Search failed for tag {tag}, continuing with next tag")
                    break
                    
                users = results.get("data", {}).get("items", [])
                if not users:
                    logger.info(f"No more users found for tag {tag}")
                    break
                
                # Filter users by minimum reputation
                qualified_users = [user for user in users if user.get("reputation", 0) >= min_reputation]
                
                # Add unique users to our list
                existing_user_ids = [expert.get("stackoverflow_user_id") for expert in all_experts]
                for user in qualified_users:
                    user_id = user.get("user_id")
                    if user_id not in existing_user_ids:
                        # Get detailed expertise analysis
                        expertise_analysis = self.analyze_developer_expertise(user_id)
                        if expertise_analysis.get("success"):
                            all_experts.append(expertise_analysis.get("data", {}))
                            
                            # Check if we've reached the limit
                            if len(all_experts) >= limit:
                                break
                
                page += 1
        
        # Limit results to requested number
        limited_experts = all_experts[:limit]
        
        logger.info(f"Retrieved and analyzed {len(limited_experts)} experts")
        return limited_experts

# Example usage
if __name__ == "__main__":
    collector = StackOverflowDataCollector()
    
    # Example: Search for Python experts
    python_experts = collector.search_tech_experts(
        tech_tags=["python", "django", "flask"],
        min_reputation=5000,
        limit=5
    )
    
    # Save results to file
    with open('stackoverflow_python_experts.json', 'w') as f:
        json.dump(python_experts, f, indent=2)
    
    print(f"Found {len(python_experts)} Python experts on Stack Overflow")
