"""
LinkedIn Data Collector for Candidate Sourcing AI Module

This module handles the integration with LinkedIn API to collect candidate data.
It includes authentication, search, profile retrieval, and data normalization.
"""

import sys
import json
import logging
from typing import Dict, List, Optional, Any

sys.path.append('/opt/.manus/.sandbox-runtime')
from data_api import ApiClient

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class LinkedInDataCollector:
    """
    LinkedIn Data Collector class for retrieving and processing candidate data from LinkedIn.
    """
    
    def __init__(self):
        """Initialize the LinkedIn Data Collector with API client."""
        self.client = ApiClient()
        logger.info("LinkedIn Data Collector initialized")
    
    def search_candidates(self, 
                         keywords: str, 
                         title: Optional[str] = None, 
                         company: Optional[str] = None, 
                         start: int = 0,
                         first_name: Optional[str] = None,
                         last_name: Optional[str] = None,
                         school: Optional[str] = None) -> Dict[str, Any]:
        """
        Search for candidates on LinkedIn based on provided criteria.
        
        Args:
            keywords: Main search keywords
            title: Job title to search for
            company: Company name to search for
            start: Pagination start index
            first_name: Candidate's first name
            last_name: Candidate's last name
            school: Educational institution
            
        Returns:
            Dictionary containing search results
        """
        logger.info(f"Searching LinkedIn candidates with keywords: {keywords}")
        
        # Construct query parameters
        query_params = {
            'keywords': keywords,
            'start': str(start)
        }
        
        # Add optional parameters if provided
        if title:
            query_params['keywordTitle'] = title
        if company:
            query_params['company'] = company
        if first_name:
            query_params['firstName'] = first_name
        if last_name:
            query_params['lastName'] = last_name
        if school:
            query_params['keywordSchool'] = school
        
        try:
            # Call the LinkedIn API
            results = self.client.call_api('LinkedIn/search_people', query=query_params)
            
            if results.get('success'):
                logger.info(f"Successfully retrieved {len(results.get('data', {}).get('items', []))} candidates")
                return results
            else:
                logger.error(f"LinkedIn API search failed: {results.get('message')}")
                return {"success": False, "message": results.get('message'), "data": {"items": []}}
                
        except Exception as e:
            logger.exception(f"Error searching LinkedIn candidates: {str(e)}")
            return {"success": False, "message": str(e), "data": {"items": []}}
    
    def get_candidate_profile(self, username: str) -> Dict[str, Any]:
        """
        Retrieve detailed profile information for a specific LinkedIn user.
        
        Args:
            username: LinkedIn username
            
        Returns:
            Dictionary containing profile data
        """
        logger.info(f"Retrieving profile for LinkedIn user: {username}")
        
        try:
            # Call the LinkedIn API
            profile = self.client.call_api('LinkedIn/get_user_profile_by_username', 
                                          query={'username': username})
            
            if profile.get('success'):
                logger.info(f"Successfully retrieved profile for {username}")
                return profile
            else:
                logger.error(f"LinkedIn API profile retrieval failed: {profile.get('message')}")
                return {"success": False, "message": profile.get('message'), "data": {}}
                
        except Exception as e:
            logger.exception(f"Error retrieving LinkedIn profile: {str(e)}")
            return {"success": False, "message": str(e), "data": {}}
    
    def get_company_details(self, company_name: str) -> Dict[str, Any]:
        """
        Retrieve detailed information about a company on LinkedIn.
        
        Args:
            company_name: Name of the company
            
        Returns:
            Dictionary containing company data
        """
        logger.info(f"Retrieving company details for: {company_name}")
        
        try:
            # Call the LinkedIn API
            company_details = self.client.call_api('LinkedIn/get_company_details', 
                                                 query={'username': company_name})
            
            if company_details.get('success'):
                logger.info(f"Successfully retrieved company details for {company_name}")
                return company_details
            else:
                logger.error(f"LinkedIn API company details retrieval failed: {company_details.get('message')}")
                return {"success": False, "message": company_details.get('message'), "data": {}}
                
        except Exception as e:
            logger.exception(f"Error retrieving company details: {str(e)}")
            return {"success": False, "message": str(e), "data": {}}
    
    def normalize_candidate_data(self, profile_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Normalize and structure raw LinkedIn profile data.
        
        Args:
            profile_data: Raw profile data from LinkedIn API
            
        Returns:
            Normalized candidate data dictionary
        """
        logger.info("Normalizing candidate profile data")
        
        if not profile_data.get('success'):
            return {"success": False, "message": "No valid profile data to normalize"}
        
        try:
            data = profile_data.get('data', {})
            
            # Extract basic profile information
            normalized_data = {
                "source": "linkedin",
                "source_id": data.get('id', ''),
                "username": data.get('username', ''),
                "profile_url": data.get('linkedinUrl', ''),
                "basic_info": {
                    "first_name": data.get('firstName', ''),
                    "last_name": data.get('lastName', ''),
                    "full_name": f"{data.get('firstName', '')} {data.get('lastName', '')}".strip(),
                    "headline": data.get('headline', ''),
                    "location": data.get('location', ''),
                    "profile_picture": data.get('profilePicture', '')
                },
                "experience": [],
                "education": [],
                "skills": [],
                "languages": [],
                "certifications": [],
                "projects": [],
                "recommendations": [],
                "volunteer_experience": [],
                "publications": [],
                "patents": [],
                "open_to_work": data.get('openToWork', False),
                "last_updated": data.get('lastUpdated', '')
            }
            
            # Process experience data
            if 'experience' in data:
                for exp in data.get('experience', []):
                    experience_entry = {
                        "title": exp.get('title', ''),
                        "company": exp.get('companyName', ''),
                        "location": exp.get('location', ''),
                        "start_date": exp.get('dateRange', {}).get('start', ''),
                        "end_date": exp.get('dateRange', {}).get('end', ''),
                        "is_current": exp.get('isCurrent', False),
                        "description": exp.get('description', ''),
                        "duration": exp.get('duration', '')
                    }
                    normalized_data["experience"].append(experience_entry)
            
            # Process education data
            if 'education' in data:
                for edu in data.get('education', []):
                    education_entry = {
                        "school": edu.get('schoolName', ''),
                        "degree": edu.get('degreeName', ''),
                        "field_of_study": edu.get('fieldOfStudy', ''),
                        "start_date": edu.get('dateRange', {}).get('start', ''),
                        "end_date": edu.get('dateRange', {}).get('end', ''),
                        "description": edu.get('description', '')
                    }
                    normalized_data["education"].append(education_entry)
            
            # Process skills data
            if 'skills' in data:
                normalized_data["skills"] = [skill.get('name', '') for skill in data.get('skills', [])]
            
            # Process languages data
            if 'languages' in data:
                for lang in data.get('languages', []):
                    language_entry = {
                        "name": lang.get('name', ''),
                        "proficiency": lang.get('proficiency', '')
                    }
                    normalized_data["languages"].append(language_entry)
            
            # Process certifications data
            if 'certifications' in data:
                for cert in data.get('certifications', []):
                    certification_entry = {
                        "name": cert.get('name', ''),
                        "issuing_organization": cert.get('authority', ''),
                        "issue_date": cert.get('issueDate', ''),
                        "expiration_date": cert.get('expirationDate', ''),
                        "credential_id": cert.get('licenseNumber', '')
                    }
                    normalized_data["certifications"].append(certification_entry)
            
            logger.info("Successfully normalized candidate profile data")
            return {"success": True, "data": normalized_data}
            
        except Exception as e:
            logger.exception(f"Error normalizing candidate data: {str(e)}")
            return {"success": False, "message": str(e), "data": {}}
    
    def search_tech_candidates(self, 
                              tech_keywords: List[str], 
                              title: Optional[str] = None,
                              experience_level: Optional[str] = None,
                              location: Optional[str] = None,
                              limit: int = 50) -> List[Dict[str, Any]]:
        """
        Specialized search for technical candidates based on tech skills.
        
        Args:
            tech_keywords: List of technical skills to search for
            title: Job title to search for
            experience_level: Experience level (e.g., "Entry", "Senior")
            location: Geographic location
            limit: Maximum number of candidates to return
            
        Returns:
            List of candidate dictionaries
        """
        logger.info(f"Searching for tech candidates with skills: {', '.join(tech_keywords)}")
        
        all_candidates = []
        keywords_str = " ".join(tech_keywords)
        
        # Add experience level to search if provided
        if experience_level:
            if experience_level.lower() == "entry":
                title_with_level = f"Junior {title}" if title else "Junior"
            elif experience_level.lower() == "mid":
                title_with_level = f"Mid-level {title}" if title else "Mid-level"
            elif experience_level.lower() == "senior":
                title_with_level = f"Senior {title}" if title else "Senior"
            elif experience_level.lower() == "lead":
                title_with_level = f"Lead {title}" if title else "Lead"
            else:
                title_with_level = title
        else:
            title_with_level = title
        
        # Perform initial search
        start = 0
        while len(all_candidates) < limit:
            results = self.search_candidates(
                keywords=keywords_str,
                title=title_with_level,
                start=start
            )
            
            if not results.get('success'):
                logger.error("Search failed, returning partial results")
                break
                
            candidates = results.get('data', {}).get('items', [])
            if not candidates:
                logger.info("No more candidates found")
                break
                
            all_candidates.extend(candidates)
            start += len(candidates)
            
            # Check if we've reached the end of results
            if len(candidates) < 10:  # LinkedIn typically returns 10 results per page
                break
        
        # Limit results to requested number
        limited_candidates = all_candidates[:limit]
        
        # Normalize candidate data
        normalized_candidates = []
        for candidate in limited_candidates:
            # Extract username from profile URL
            profile_url = candidate.get('profileURL', '')
            username = profile_url.split('/')[-1] if profile_url else None
            
            if username:
                # Get detailed profile
                profile_data = self.get_candidate_profile(username)
                if profile_data.get('success'):
                    normalized_data = self.normalize_candidate_data(profile_data)
                    if normalized_data.get('success'):
                        normalized_candidates.append(normalized_data.get('data', {}))
            
        logger.info(f"Retrieved and normalized {len(normalized_candidates)} tech candidates")
        return normalized_candidates

# Example usage
if __name__ == "__main__":
    collector = LinkedInDataCollector()
    
    # Example: Search for Python developers
    python_devs = collector.search_tech_candidates(
        tech_keywords=["Python", "Django", "Flask"],
        title="Software Engineer",
        experience_level="Senior",
        limit=5
    )
    
    # Save results to file
    with open('python_developers.json', 'w') as f:
        json.dump(python_devs, f, indent=2)
    
    print(f"Found {len(python_devs)} Python developers")
