"""
GitHub Data Collector for Candidate Sourcing AI Module

This module handles the integration with GitHub API to collect developer data.
It includes repository analysis, contribution metrics, and skill identification.
"""

import os
import json
import logging
import requests
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class GitHubDataCollector:
    """
    GitHub Data Collector class for retrieving and processing developer data from GitHub.
    """
    
    def __init__(self, api_token: Optional[str] = None):
        """
        Initialize the GitHub Data Collector with API token.
        
        Args:
            api_token: GitHub API token for authentication (optional)
        """
        self.api_token = api_token or os.environ.get('GITHUB_API_TOKEN')
        self.base_url = "https://api.github.com"
        self.headers = {
            "Accept": "application/vnd.github.v3+json"
        }
        
        if self.api_token:
            self.headers["Authorization"] = f"token {self.api_token}"
            
        logger.info("GitHub Data Collector initialized")
    
    def _make_request(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Make a request to the GitHub API.
        
        Args:
            endpoint: API endpoint to call
            params: Query parameters
            
        Returns:
            API response as dictionary
        """
        url = f"{self.base_url}/{endpoint}"
        
        try:
            response = requests.get(url, headers=self.headers, params=params)
            response.raise_for_status()
            return {"success": True, "data": response.json()}
        except requests.exceptions.RequestException as e:
            logger.error(f"GitHub API request failed: {str(e)}")
            return {"success": False, "message": str(e), "data": {}}
    
    def search_users(self, 
                    query: str, 
                    language: Optional[str] = None,
                    location: Optional[str] = None,
                    followers: Optional[str] = None,
                    sort: str = "repositories",
                    order: str = "desc",
                    per_page: int = 30,
                    page: int = 1) -> Dict[str, Any]:
        """
        Search for GitHub users based on provided criteria.
        
        Args:
            query: Search query string
            language: Programming language filter
            location: Geographic location filter
            followers: Minimum number of followers (e.g., ">=100")
            sort: Sort field (repositories, followers, joined)
            order: Sort order (asc, desc)
            per_page: Results per page (max 100)
            page: Page number
            
        Returns:
            Dictionary containing search results
        """
        logger.info(f"Searching GitHub users with query: {query}")
        
        # Build the search query
        search_query = query
        
        if language:
            search_query += f" language:{language}"
        
        if location:
            search_query += f" location:{location}"
        
        if followers:
            search_query += f" followers:{followers}"
        
        params = {
            "q": search_query,
            "sort": sort,
            "order": order,
            "per_page": per_page,
            "page": page
        }
        
        return self._make_request("search/users", params)
    
    def get_user_profile(self, username: str) -> Dict[str, Any]:
        """
        Retrieve detailed profile information for a GitHub user.
        
        Args:
            username: GitHub username
            
        Returns:
            Dictionary containing user profile data
        """
        logger.info(f"Retrieving profile for GitHub user: {username}")
        return self._make_request(f"users/{username}")
    
    def get_user_repositories(self, username: str, per_page: int = 100, page: int = 1) -> Dict[str, Any]:
        """
        Retrieve repositories for a GitHub user.
        
        Args:
            username: GitHub username
            per_page: Results per page (max 100)
            page: Page number
            
        Returns:
            Dictionary containing user repositories
        """
        logger.info(f"Retrieving repositories for GitHub user: {username}")
        
        params = {
            "sort": "updated",
            "direction": "desc",
            "per_page": per_page,
            "page": page
        }
        
        return self._make_request(f"users/{username}/repos", params)
    
    def get_repository_languages(self, username: str, repo: str) -> Dict[str, Any]:
        """
        Retrieve languages used in a repository.
        
        Args:
            username: GitHub username
            repo: Repository name
            
        Returns:
            Dictionary containing language data
        """
        logger.info(f"Retrieving languages for repository: {username}/{repo}")
        return self._make_request(f"repos/{username}/{repo}/languages")
    
    def get_user_contributions(self, username: str, since: Optional[str] = None) -> Dict[str, Any]:
        """
        Retrieve contribution activity for a GitHub user.
        
        Args:
            username: GitHub username
            since: Start date for contributions (ISO format)
            
        Returns:
            Dictionary containing contribution data
        """
        logger.info(f"Retrieving contributions for GitHub user: {username}")
        
        # If since is not provided, default to one year ago
        if not since:
            one_year_ago = datetime.now() - timedelta(days=365)
            since = one_year_ago.strftime("%Y-%m-%dT%H:%M:%SZ")
        
        params = {"since": since}
        return self._make_request(f"users/{username}/events", params)
    
    def analyze_developer_skills(self, username: str) -> Dict[str, Any]:
        """
        Analyze a developer's skills based on their GitHub activity.
        
        Args:
            username: GitHub username
            
        Returns:
            Dictionary containing skill analysis
        """
        logger.info(f"Analyzing skills for GitHub user: {username}")
        
        # Get user profile
        profile_result = self.get_user_profile(username)
        if not profile_result.get("success"):
            return {"success": False, "message": "Failed to retrieve user profile", "data": {}}
        
        profile = profile_result.get("data", {})
        
        # Get user repositories
        repos_result = self.get_user_repositories(username)
        if not repos_result.get("success"):
            return {"success": False, "message": "Failed to retrieve user repositories", "data": {}}
        
        repos = repos_result.get("data", [])
        
        # Analyze languages across repositories
        language_stats = {}
        for repo in repos:
            # Skip forks if they're not the user's original work
            if repo.get("fork", False):
                continue
                
            repo_name = repo.get("name")
            languages_result = self.get_repository_languages(username, repo_name)
            
            if languages_result.get("success"):
                repo_languages = languages_result.get("data", {})
                
                for language, bytes_count in repo_languages.items():
                    if language in language_stats:
                        language_stats[language] += bytes_count
                    else:
                        language_stats[language] = bytes_count
        
        # Calculate percentages and sort by usage
        total_bytes = sum(language_stats.values()) if language_stats else 1
        language_percentages = {lang: (count / total_bytes) * 100 for lang, count in language_stats.items()}
        sorted_languages = sorted(language_percentages.items(), key=lambda x: x[1], reverse=True)
        
        # Get contribution activity
        contributions_result = self.get_user_contributions(username)
        contribution_count = len(contributions_result.get("data", [])) if contributions_result.get("success") else 0
        
        # Prepare skill analysis result
        skill_analysis = {
            "github_username": username,
            "profile_url": profile.get("html_url"),
            "name": profile.get("name"),
            "company": profile.get("company"),
            "blog": profile.get("blog"),
            "location": profile.get("location"),
            "email": profile.get("email"),
            "bio": profile.get("bio"),
            "public_repos": profile.get("public_repos", 0),
            "followers": profile.get("followers", 0),
            "following": profile.get("following", 0),
            "created_at": profile.get("created_at"),
            "updated_at": profile.get("updated_at"),
            "languages": [{"name": lang, "percentage": pct} for lang, pct in sorted_languages],
            "top_languages": [lang for lang, _ in sorted_languages[:5]],
            "repositories": [
                {
                    "name": repo.get("name"),
                    "description": repo.get("description"),
                    "url": repo.get("html_url"),
                    "stars": repo.get("stargazers_count", 0),
                    "forks": repo.get("forks_count", 0),
                    "language": repo.get("language"),
                    "created_at": repo.get("created_at"),
                    "updated_at": repo.get("updated_at")
                }
                for repo in sorted(repos, key=lambda x: x.get("stargazers_count", 0), reverse=True)[:10]
                if not repo.get("fork", False)
            ],
            "recent_activity_level": "High" if contribution_count > 100 else "Medium" if contribution_count > 30 else "Low",
            "contribution_count": contribution_count
        }
        
        return {"success": True, "data": skill_analysis}
    
    def search_tech_developers(self, 
                              tech_skills: List[str], 
                              location: Optional[str] = None,
                              min_followers: Optional[int] = None,
                              limit: int = 50) -> List[Dict[str, Any]]:
        """
        Search for developers with specific technical skills.
        
        Args:
            tech_skills: List of technical skills to search for
            location: Geographic location filter
            min_followers: Minimum number of followers
            limit: Maximum number of developers to return
            
        Returns:
            List of developer dictionaries with skill analysis
        """
        logger.info(f"Searching for developers with skills: {', '.join(tech_skills)}")
        
        all_developers = []
        
        # Search for each skill separately to maximize results
        for skill in tech_skills:
            followers_param = f">={min_followers}" if min_followers else None
            
            # Perform initial search
            page = 1
            while len(all_developers) < limit:
                results = self.search_users(
                    query=skill,
                    language=skill if skill in ["python", "javascript", "java", "go", "rust", "c++", "typescript"] else None,
                    location=location,
                    followers=followers_param,
                    per_page=30,
                    page=page
                )
                
                if not results.get("success"):
                    logger.error(f"Search failed for skill {skill}, continuing with next skill")
                    break
                    
                users = results.get("data", {}).get("items", [])
                if not users:
                    logger.info(f"No more users found for skill {skill}")
                    break
                
                # Add unique users to our list
                existing_usernames = [dev.get("github_username") for dev in all_developers]
                for user in users:
                    username = user.get("login")
                    if username not in existing_usernames:
                        # Get detailed skill analysis
                        skill_analysis = self.analyze_developer_skills(username)
                        if skill_analysis.get("success"):
                            all_developers.append(skill_analysis.get("data", {}))
                            
                            # Check if we've reached the limit
                            if len(all_developers) >= limit:
                                break
                
                page += 1
        
        # Limit results to requested number
        limited_developers = all_developers[:limit]
        
        logger.info(f"Retrieved and analyzed {len(limited_developers)} developers")
        return limited_developers

# Example usage
if __name__ == "__main__":
    collector = GitHubDataCollector()
    
    # Example: Search for Python developers
    python_devs = collector.search_tech_developers(
        tech_skills=["python", "django", "flask"],
        location="San Francisco",
        min_followers=50,
        limit=5
    )
    
    # Save results to file
    with open('github_python_developers.json', 'w') as f:
        json.dump(python_devs, f, indent=2)
    
    print(f"Found {len(python_devs)} Python developers on GitHub")
