"""
Candidate Matching Engine for Sourcing AI Module

This module implements the AI-powered candidate matching algorithm that evaluates
candidates against job requirements and produces match scores.
"""

import logging
import numpy as np
from typing import Dict, List, Any, Optional
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import joblib
import os
import json

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class CandidateMatchingEngine:
    """
    AI-powered engine for matching candidates to job requirements.
    """
    
    def __init__(self, model_path: Optional[str] = None):
        """
        Initialize the Candidate Matching Engine.
        
        Args:
            model_path: Path to pre-trained model (optional)
        """
        self.model_path = model_path
        self.vectorizer = TfidfVectorizer(stop_words='english')
        self.skill_weights = {}
        self.experience_weights = {
            "years": 0.4,
            "relevance": 0.6
        }
        
        # Load pre-trained model if available
        if model_path and os.path.exists(model_path):
            try:
                self.model = joblib.load(model_path)
                logger.info(f"Loaded pre-trained model from {model_path}")
            except Exception as e:
                logger.error(f"Failed to load model: {str(e)}")
                self.model = None
        else:
            self.model = None
            
        logger.info("Candidate Matching Engine initialized")
    
    def extract_skills(self, text: str) -> List[str]:
        """
        Extract skills from text using NLP techniques.
        
        Args:
            text: Text to extract skills from
            
        Returns:
            List of extracted skills
        """
        # This is a simplified implementation
        # In a production system, this would use a more sophisticated NER model
        
        # Common tech skills to look for
        tech_skills = [
            "python", "java", "javascript", "typescript", "c++", "c#", "ruby", "go", "rust",
            "react", "angular", "vue", "node.js", "django", "flask", "spring", "express",
            "aws", "azure", "gcp", "docker", "kubernetes", "terraform", "jenkins", "git",
            "sql", "postgresql", "mysql", "mongodb", "redis", "elasticsearch",
            "machine learning", "deep learning", "nlp", "computer vision", "data science",
            "agile", "scrum", "devops", "ci/cd", "tdd", "rest api", "graphql"
        ]
        
        # Convert text to lowercase for case-insensitive matching
        text_lower = text.lower()
        
        # Find skills in text
        found_skills = []
        for skill in tech_skills:
            if skill in text_lower:
                found_skills.append(skill)
                
        return found_skills
    
    def normalize_skills(self, skills: List[str]) -> List[str]:
        """
        Normalize skills to handle variations and synonyms.
        
        Args:
            skills: List of skills to normalize
            
        Returns:
            List of normalized skills
        """
        # Skill normalization mapping
        normalization_map = {
            "js": "javascript",
            "ts": "typescript",
            "py": "python",
            "react.js": "react",
            "reactjs": "react",
            "node": "node.js",
            "nodejs": "node.js",
            "postgres": "postgresql",
            "mongo": "mongodb",
            "k8s": "kubernetes",
            "ml": "machine learning",
            "ai": "artificial intelligence",
            "vue.js": "vue",
            "vuejs": "vue",
            "angular.js": "angular",
            "angularjs": "angular"
        }
        
        normalized = []
        for skill in skills:
            skill_lower = skill.lower().strip()
            normalized.append(normalization_map.get(skill_lower, skill_lower))
            
        return list(set(normalized))  # Remove duplicates
    
    def calculate_skill_match(self, 
                             candidate_skills: List[str], 
                             required_skills: List[str],
                             preferred_skills: List[str]) -> Dict[str, Any]:
        """
        Calculate skill match score between candidate and job requirements.
        
        Args:
            candidate_skills: List of candidate's skills
            required_skills: List of required skills for the job
            preferred_skills: List of preferred skills for the job
            
        Returns:
            Dictionary with match scores and details
        """
        # Normalize all skills
        candidate_skills_norm = self.normalize_skills(candidate_skills)
        required_skills_norm = self.normalize_skills(required_skills)
        preferred_skills_norm = self.normalize_skills(preferred_skills)
        
        # Calculate required skills match
        required_matches = [skill for skill in required_skills_norm if skill in candidate_skills_norm]
        required_match_count = len(required_matches)
        required_total = len(required_skills_norm) if required_skills_norm else 1
        required_match_score = (required_match_count / required_total) * 100
        
        # Calculate preferred skills match
        preferred_matches = [skill for skill in preferred_skills_norm if skill in candidate_skills_norm]
        preferred_match_count = len(preferred_matches)
        preferred_total = len(preferred_skills_norm) if preferred_skills_norm else 1
        preferred_match_score = (preferred_match_count / preferred_total) * 100
        
        # Calculate overall skill match score (70% required, 30% preferred)
        overall_skill_score = (required_match_score * 0.7) + (preferred_match_score * 0.3)
        
        # Missing required skills
        missing_required = [skill for skill in required_skills_norm if skill not in candidate_skills_norm]
        
        return {
            "overall_skill_score": overall_skill_score,
            "required_match_score": required_match_score,
            "preferred_match_score": preferred_match_score,
            "required_matches": required_matches,
            "preferred_matches": preferred_matches,
            "missing_required": missing_required,
            "has_all_required": len(missing_required) == 0
        }
    
    def calculate_experience_match(self, 
                                  candidate_experience: List[Dict[str, Any]], 
                                  required_years: int,
                                  job_title: str,
                                  job_description: str) -> Dict[str, Any]:
        """
        Calculate experience match score between candidate and job requirements.
        
        Args:
            candidate_experience: List of candidate's experience entries
            required_years: Required years of experience for the job
            job_title: Job title
            job_description: Job description
            
        Returns:
            Dictionary with match scores and details
        """
        # Calculate total years of experience
        total_years = 0
        relevant_years = 0
        
        for exp in candidate_experience:
            # Calculate duration of this experience
            start_date = exp.get("start_date", "")
            end_date = exp.get("end_date", "")
            is_current = exp.get("is_current", False)
            
            # Simple duration calculation (in a real system, use proper date parsing)
            duration = 0
            if "years" in exp.get("duration", ""):
                try:
                    duration = float(exp.get("duration", "").split()[0])
                except (ValueError, IndexError):
                    duration = 1  # Default to 1 year if parsing fails
            
            total_years += duration
            
            # Calculate relevance of this experience to the job
            exp_title = exp.get("title", "").lower()
            exp_description = exp.get("description", "").lower()
            job_title_lower = job_title.lower()
            
            # Create document vectors for similarity comparison
            docs = [job_description, exp_description]
            try:
                tfidf_matrix = self.vectorizer.fit_transform(docs)
                relevance_score = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
            except:
                relevance_score = 0.5  # Default if calculation fails
            
            # Adjust relevance score based on title match
            if job_title_lower in exp_title:
                relevance_score = min(1.0, relevance_score + 0.3)
            
            # Calculate relevant years for this experience
            exp_relevant_years = duration * relevance_score
            relevant_years += exp_relevant_years
        
        # Calculate years match score
        years_match_score = min(100, (relevant_years / required_years) * 100) if required_years > 0 else 100
        
        # Calculate overall experience match score
        overall_experience_score = (years_match_score * self.experience_weights["years"]) + \
                                  (min(100, (total_years / required_years) * 100) * self.experience_weights["relevance"]) \
                                  if required_years > 0 else 100
        
        return {
            "overall_experience_score": overall_experience_score,
            "years_match_score": years_match_score,
            "total_years": total_years,
            "relevant_years": relevant_years,
            "required_years": required_years,
            "meets_years_requirement": relevant_years >= required_years
        }
    
    def calculate_education_match(self, 
                                 candidate_education: List[Dict[str, Any]], 
                                 required_degree: Optional[str] = None,
                                 preferred_fields: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Calculate education match score between candidate and job requirements.
        
        Args:
            candidate_education: List of candidate's education entries
            required_degree: Required degree level (e.g., "Bachelor's", "Master's")
            preferred_fields: Preferred fields of study
            
        Returns:
            Dictionary with match scores and details
        """
        # Degree level hierarchy
        degree_levels = {
            "high school": 1,
            "associate": 2,
            "associate's": 2,
            "bachelor": 3,
            "bachelor's": 3,
            "master": 4,
            "master's": 4,
            "mba": 4,
            "phd": 5,
            "doctorate": 5
        }
        
        # Find highest degree level
        highest_degree = 0
        highest_degree_name = ""
        field_matches = []
        
        for edu in candidate_education:
            degree = edu.get("degree", "").lower()
            field = edu.get("field_of_study", "").lower()
            
            # Determine degree level
            for level_name, level_value in degree_levels.items():
                if level_name in degree:
                    if level_value > highest_degree:
                        highest_degree = level_value
                        highest_degree_name = degree
            
            # Check for field matches
            if preferred_fields:
                for preferred_field in preferred_fields:
                    if preferred_field.lower() in field:
                        field_matches.append(preferred_field)
        
        # Calculate degree match score
        degree_match_score = 0
        if required_degree:
            required_level = 0
            for level_name, level_value in degree_levels.items():
                if level_name in required_degree.lower():
                    required_level = level_value
                    break
            
            if highest_degree >= required_level:
                degree_match_score = 100
            else:
                degree_match_score = (highest_degree / required_level) * 100
        else:
            # If no specific degree is required, give full score
            degree_match_score = 100
        
        # Calculate field match score
        field_match_score = 0
        if preferred_fields:
            unique_matches = set(field_matches)
            field_match_score = (len(unique_matches) / len(preferred_fields)) * 100
        else:
            # If no specific fields are preferred, give full score
            field_match_score = 100
        
        # Calculate overall education match score (70% degree, 30% field)
        overall_education_score = (degree_match_score * 0.7) + (field_match_score * 0.3)
        
        return {
            "overall_education_score": overall_education_score,
            "degree_match_score": degree_match_score,
            "field_match_score": field_match_score,
            "highest_degree": highest_degree_name,
            "field_matches": list(set(field_matches)),
            "meets_degree_requirement": degree_match_score >= 100
        }
    
    def calculate_location_match(self, 
                               candidate_location: str, 
                               job_location: str,
                               remote_ok: bool = False) -> Dict[str, Any]:
        """
        Calculate location match score between candidate and job location.
        
        Args:
            candidate_location: Candidate's location
            job_location: Job location
            remote_ok: Whether remote work is acceptable
            
        Returns:
            Dictionary with match scores and details
        """
        # Simplistic location matching - in a real system, use geocoding and distance calculation
        
        # Check for remote indicators
        candidate_remote = "remote" in candidate_location.lower()
        job_remote = "remote" in job_location.lower()
        
        # Perfect match cases
        if candidate_remote and job_remote:
            return {
                "location_match_score": 100,
                "is_match": True,
                "match_type": "remote_to_remote"
            }
        
        if remote_ok and candidate_remote:
            return {
                "location_match_score": 100,
                "is_match": True,
                "match_type": "remote_ok"
            }
        
        # Normalize locations (remove common words, convert to lowercase)
        def normalize_location(loc):
            return ' '.join([
                word for word in loc.lower().replace(',', ' ').split()
                if word not in ['remote', 'area', 'greater', 'region']
            ])
        
        norm_candidate_loc = normalize_location(candidate_location)
        norm_job_loc = normalize_location(job_location)
        
        # Check for exact location match
        if norm_candidate_loc == norm_job_loc:
            return {
                "location_match_score": 100,
                "is_match": True,
                "match_type": "exact_location"
            }
        
        # Check for partial location match (e.g., same city or state)
        candidate_parts = set(norm_candidate_loc.split())
        job_parts = set(norm_job_loc.split())
        common_parts = candidate_parts.intersection(job_parts)
        
        if common_parts:
            match_score = (len(common_parts) / max(len(candidate_parts), len(job_parts))) * 100
            return {
                "location_match_score": match_score,
                "is_match": match_score >= 50,
                "match_type": "partial_location",
                "common_terms": list(common_parts)
    <response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>