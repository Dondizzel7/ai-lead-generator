"""
Outreach Automation System for Sourcing AI Module

This module implements the automated outreach system that personalizes messages,
manages campaigns, and tracks candidate responses.
"""

import logging
import json
import os
import time
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import random
import re
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class OutreachAutomation:
    """
    Automated system for candidate outreach and engagement tracking.
    """
    
    def __init__(self, 
                email_config: Optional[Dict[str, Any]] = None,
                templates_dir: Optional[str] = None,
                data_dir: Optional[str] = None):
        """
        Initialize the Outreach Automation system.
        
        Args:
            email_config: Email server configuration
            templates_dir: Directory containing message templates
            data_dir: Directory for storing outreach data
        """
        self.email_config = email_config or {}
        self.templates_dir = templates_dir or os.path.join(os.getcwd(), 'templates')
        self.data_dir = data_dir or os.path.join(os.getcwd(), 'data')
        
        # Create directories if they don't exist
        os.makedirs(self.templates_dir, exist_ok=True)
        os.makedirs(self.data_dir, exist_ok=True)
        
        # Load templates
        self.templates = self._load_templates()
        
        # Initialize campaign data
        self.campaigns = self._load_campaigns()
        
        logger.info("Outreach Automation system initialized")
    
    def _load_templates(self) -> Dict[str, Any]:
        """
        Load message templates from the templates directory.
        
        Returns:
            Dictionary of templates
        """
        templates = {}
        template_files = [f for f in os.listdir(self.templates_dir) if f.endswith('.json')]
        
        for file in template_files:
            try:
                with open(os.path.join(self.templates_dir, file), 'r') as f:
                    template_data = json.load(f)
                    template_id = os.path.splitext(file)[0]
                    templates[template_id] = template_data
                    logger.info(f"Loaded template: {template_id}")
            except Exception as e:
                logger.error(f"Failed to load template {file}: {str(e)}")
        
        # If no templates found, create default templates
        if not templates:
            self._create_default_templates()
            return self._load_templates()
        
        return templates
    
    def _create_default_templates(self):
        """Create default message templates."""
        default_templates = {
            "initial_outreach": {
                "subject": "Opportunity at {{company_name}}",
                "body": """Hello {{candidate_first_name}},

I hope this message finds you well. I'm {{recruiter_name}} from {{company_name}}, and I was impressed by your background in {{skill_area}}.

We're currently looking for a {{job_title}} to join our team, and your experience with {{key_skill}} caught my attention.

Would you be interested in learning more about this opportunity? If so, I'd be happy to share more details.

Best regards,
{{recruiter_name}}
{{recruiter_title}}
{{company_name}}
{{recruiter_email}}
{{recruiter_phone}}
""",
                "type": "initial",
                "variables": ["candidate_first_name", "recruiter_name", "company_name", 
                             "skill_area", "job_title", "key_skill", "recruiter_title", 
                             "recruiter_email", "recruiter_phone"]
            },
            "follow_up_1": {
                "subject": "Following up: Opportunity at {{company_name}}",
                "body": """Hello {{candidate_first_name}},

I wanted to follow up on my previous message about the {{job_title}} role at {{company_name}}.

Given your experience with {{key_skill}}, I believe this could be a great fit for your career growth.

If you're interested, I'd be happy to schedule a quick call to discuss the opportunity in more detail.

Best regards,
{{recruiter_name}}
{{recruiter_title}}
{{company_name}}
{{recruiter_email}}
{{recruiter_phone}}
""",
                "type": "follow_up",
                "variables": ["candidate_first_name", "recruiter_name", "company_name", 
                             "job_title", "key_skill", "recruiter_title", 
                             "recruiter_email", "recruiter_phone"]
            },
            "follow_up_2": {
                "subject": "One last note about {{job_title}} at {{company_name}}",
                "body": """Hello {{candidate_first_name}},

I wanted to reach out one final time regarding the {{job_title}} position at {{company_name}}.

We're looking for someone with your expertise in {{skill_area}}, and I'd hate for you to miss this opportunity.

If you're interested, please let me know. If I don't hear back, I'll assume the timing isn't right, and I won't bother you again.

Best regards,
{{recruiter_name}}
{{recruiter_title}}
{{company_name}}
{{recruiter_email}}
{{recruiter_phone}}
""",
                "type": "final_follow_up",
                "variables": ["candidate_first_name", "recruiter_name", "company_name", 
                             "skill_area", "job_title", "recruiter_title", 
                             "recruiter_email", "recruiter_phone"]
            }
        }
        
        for template_id, template_data in default_templates.items():
            try:
                with open(os.path.join(self.templates_dir, f"{template_id}.json"), 'w') as f:
                    json.dump(template_data, f, indent=2)
                logger.info(f"Created default template: {template_id}")
            except Exception as e:
                logger.error(f"Failed to create default template {template_id}: {str(e)}")
    
    def _load_campaigns(self) -> Dict[str, Any]:
        """
        Load campaign data from the data directory.
        
        Returns:
            Dictionary of campaigns
        """
        campaigns = {}
        campaign_files = [f for f in os.listdir(self.data_dir) if f.startswith('campaign_') and f.endswith('.json')]
        
        for file in campaign_files:
            try:
                with open(os.path.join(self.data_dir, file), 'r') as f:
                    campaign_data = json.load(f)
                    campaign_id = campaign_data.get('id')
                    if campaign_id:
                        campaigns[campaign_id] = campaign_data
                        logger.info(f"Loaded campaign: {campaign_id}")
            except Exception as e:
                logger.error(f"Failed to load campaign {file}: {str(e)}")
        
        return campaigns
    
    def _save_campaign(self, campaign_id: str, campaign_data: Dict[str, Any]):
        """
        Save campaign data to file.
        
        Args:
            campaign_id: Campaign identifier
            campaign_data: Campaign data to save
        """
        try:
            file_path = os.path.join(self.data_dir, f"campaign_{campaign_id}.json")
            with open(file_path, 'w') as f:
                json.dump(campaign_data, f, indent=2)
            logger.info(f"Saved campaign: {campaign_id}")
        except Exception as e:
            logger.error(f"Failed to save campaign {campaign_id}: {str(e)}")
    
    def create_template(self, 
                       template_id: str, 
                       subject: str, 
                       body: str, 
                       template_type: str = "custom",
                       variables: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Create a new message template.
        
        Args:
            template_id: Unique identifier for the template
            subject: Email subject template
            body: Email body template
            template_type: Type of template (initial, follow_up, final_follow_up, custom)
            variables: List of variables used in the template
            
        Returns:
            Template data dictionary
        """
        # Extract variables from template if not provided
        if variables is None:
            variables = []
            var_pattern = r'{{(.*?)}}'
            subject_vars = re.findall(var_pattern, subject)
            body_vars = re.findall(var_pattern, body)
            variables = list(set(subject_vars + body_vars))
        
        template_data = {
            "subject": subject,
            "body": body,
            "type": template_type,
            "variables": variables,
            "created_at": datetime.now().isoformat()
        }
        
        # Save template to file
        try:
            with open(os.path.join(self.templates_dir, f"{template_id}.json"), 'w') as f:
                json.dump(template_data, f, indent=2)
            
            # Update templates dictionary
            self.templates[template_id] = template_data
            logger.info(f"Created template: {template_id}")
            
            return template_data
        except Exception as e:
            logger.error(f"Failed to create template {template_id}: {str(e)}")
            return {"error": str(e)}
    
    def personalize_message(self, 
                           template_id: str, 
                           candidate_data: Dict[str, Any],
                           job_data: Dict[str, Any],
                           recruiter_data: Dict[str, Any],
                           additional_vars: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Personalize a message template for a specific candidate.
        
        Args:
            template_id: Template identifier
            candidate_data: Candidate profile data
            job_data: Job details data
            recruiter_data: Recruiter information
            additional_vars: Additional variables for personalization
            
        Returns:
            Dictionary with personalized subject and body
        """
        if template_id not in self.templates:
            logger.error(f"Template not found: {template_id}")
            return {"error": f"Template not found: {template_id}"}
        
        template = self.templates[template_id]
        subject_template = template.get("subject", "")
        body_template = template.get("body", "")
        
        # Prepare variables for personalization
        variables = {}
        
        # Add candidate variables
        basic_info = candidate_data.get("basic_info", {})
        variables["candidate_first_name"] = basic_info.get("first_name", "")
        variables["candidate_last_name"] = basic_info.get("last_name", "")
        variables["candidate_full_name"] = basic_info.get("full_name", "")
        variables["candidate_location"] = basic_info.get("location", "")
        
        # Extract candidate's top skills
        candidate_skills = candidate_data.get("skills", [])
        if candidate_skills:
            variables["key_skill"] = candidate_skills[0] if candidate_skills else ""
            variables["skill_area"] = ", ".join(candidate_skills[:3]) if len(candidate_skills) >= 3 else ", ".join(candidate_skills)
        
        # Add job variables
        variables["job_title"] = job_data.get("title", "")
        variables["job_location"] = job_data.get("location", "")
        variables["required_experience"] = f"{job_data.get('required_years', '')} years" if job_data.get('required_years') else ""
        
        # Add recruiter variables
        variables["recruiter_name"] = recruiter_data.get("name", "")
        variables["recruiter_title"] = recruiter_data.get("title", "")
        variables["recruiter_email"] = recruiter_data.get("email", "")
        variables["recruiter_phone"] = recruiter_data.get("phone", "")
        variables["company_name"] = recruiter_data.get("company", "")
        
        # Add additional variables
        if additional_vars:
            variables.update(additional_vars)
        
        # Personalize subject and body
        personalized_subject = subject_template
        personalized_body = body_template
        
        for var_name, var_value in variables.items():
            placeholder = f"{{{{{var_name}}}}}"
            personalized_subject = personalized_subject.replace(placeholder, str(var_value))
            personalized_body = personalized_body.replace(placeholder, str(var_value))
        
        return {
            "subject": personalized_subject,
            "body": personalized_body,
            "template_id": template_id,
            "personalized_at": datetime.now().isoformat()
        }
    
    def create_campaign(self, 
                       name: str, 
                       job_id: str,
                       initial_template_id: str,
                       follow_up_template_ids: Optional[List[str]] = None,
                       recruiter_data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Create a new outreach campaign.
        
        Args:
            name: Campaign name
            job_id: Job identifier
            initial_template_id: Template for initial messages
            follow_up_template_ids: Templates for follow-up messages
            recruiter_data: Recruiter information
            
        Returns:
            Campaign data dictionary
        """
        # Generate campaign ID
        campaign_id = f"camp_{int(time.time())}_{random.randint(1000, 9999)}"
        
        # Validate templates
        if initial_template_id not in self.templates:
            logger.error(f"Initial template not found: {initial_template_id}")
            return {"error": f"Initial template not found: {initial_template_id}"}
        
        if follow_up_template_ids:
            for template_id in follow_up_template_ids:
                if template_id not in self.templates:
                    logger.error(f"Follow-up template not found: {template_id}")
                    return {"error": f"Follow-up template not found: {template_id}"}
        
        # Create campaign data
        campaign_data = {
            "id": campaign_id,
            "name": name,
            "job_id": job_id,
            "initial_template_id": initial_template_id,
            "follow_up_template_ids": follow_up_template_ids or [],
            "recruiter_data": recruiter_data or {},
            "candidates": {},
            "status": "draft",
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
            "stats": {
                "total_candidates": 0,
                "messages_sent": 0,
                "responses_received": 0,
                "interested_candidates": 0,
                "not_interested_candidates": 0,
                "no_response_candidates": 0
            },
            "settings": {
                "send_window_start": "9:00",
                "send_window_end": "17:00",
                "timezone": "UTC",
                "days_between_follow_ups": 3,
                "max_follow_ups": len(follow_up_template_ids) if follow_up_template_ids else 0,
                "personalization_level": "medium"
            }
        }
        
        # Save campaign
        self.campaigns[campaign_id] = campaign_data
        self._save_campaign(campaign_id, campaign_data)
        
        logger.info(f"Created campaign: {campaign_id} - {name}")
        return campaign_data
    
    def add_candidates_to_campaign(self, 
                                  campaign_id: str, 
                                  candidates: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Add candidates to an existing campaign.
        
        Args:
            campa<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>