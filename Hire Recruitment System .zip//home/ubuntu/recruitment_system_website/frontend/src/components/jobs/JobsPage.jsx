import React from 'react';
import Card from '../common/Card';
import Button from '../common/Button';
import Input from '../common/Input';
import Select from '../common/Select';

const JobList = () => {
  // In a real app, this would come from Redux state
  const jobs = [
    { 
      id: 1, 
      title: 'Senior Software Engineer', 
      department: 'Engineering',
      location: 'Remote',
      applicants: 42,
      status: 'Active',
      posted: '2 weeks ago'
    },
    { 
      id: 2, 
      title: 'Product Manager', 
      department: 'Product',
      location: 'New York, NY',
      applicants: 28,
      status: 'Active',
      posted: '1 week ago'
    },
    { 
      id: 3, 
      title: 'UX Designer', 
      department: 'Design',
      location: 'San Francisco, CA',
      applicants: 35,
      status: 'Active',
      posted: '3 days ago'
    },
    { 
      id: 4, 
      title: 'Frontend Developer', 
      department: 'Engineering',
      location: 'Remote',
      applicants: 19,
      status: 'Active',
      posted: '5 days ago'
    },
    { 
      id: 5, 
      title: 'Backend Developer', 
      department: 'Engineering',
      location: 'Austin, TX',
      applicants: 23,
      status: 'Active',
      posted: '1 week ago'
    },
  ];

  return (
    <div className="bg-white shadow overflow-hidden sm:rounded-md">
      <ul className="divide-y divide-gray-200">
        {jobs.map((job) => (
          <li key={job.id}>
            <div className="px-4 py-4 sm:px-6 hover:bg-gray-50 cursor-pointer">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-900">{job.title}</p>
                  <p className="text-sm text-gray-500">{job.department} • {job.location}</p>
                </div>
                <div className="flex items-center">
                  <span className="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800 mr-2">
                    {job.status}
                  </span>
                </div>
              </div>
              <div className="mt-2 sm:flex sm:justify-between">
                <div className="sm:flex">
                  <p className="flex items-center text-sm text-gray-500">
                    {job.applicants} applicants
                  </p>
                </div>
                <div className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0">
                  Posted {job.posted}
                </div>
              </div>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

const JobFilters = () => {
  return (
    <Card>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Input 
          label="Search" 
          name="search" 
          placeholder="Search jobs..." 
        />
        <Select
          label="Department"
          name="department"
          placeholder="Select department"
          options={[
            { value: 'all', label: 'All Departments' },
            { value: 'engineering', label: 'Engineering' },
            { value: 'product', label: 'Product' },
            { value: 'design', label: 'Design' },
            { value: 'marketing', label: 'Marketing' },
            { value: 'sales', label: 'Sales' },
          ]}
        />
        <Select
          label="Location"
          name="location"
          placeholder="Select location"
          options={[
            { value: 'all', label: 'All Locations' },
            { value: 'remote', label: 'Remote' },
            { value: 'new-york', label: 'New York, NY' },
            { value: 'san-francisco', label: 'San Francisco, CA' },
            { value: 'austin', label: 'Austin, TX' },
          ]}
        />
      </div>
      <div className="mt-4 flex justify-end">
        <Button variant="outline" className="mr-2">Reset</Button>
        <Button>Apply Filters</Button>
      </div>
    </Card>
  );
};

const JobsPage = () => {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900">Jobs</h1>
        <Button>Create New Job</Button>
      </div>
      
      <JobFilters />
      
      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
          <div>
            <h3 className="text-lg leading-6 font-medium text-gray-900">Job Listings</h3>
            <p className="mt-1 max-w-2xl text-sm text-gray-500">Showing 5 of 24 jobs</p>
          </div>
          <div className="flex items-center">
            <span className="mr-2 text-sm text-gray-500">Sort by:</span>
            <Select
              name="sort"
              className="mb-0"
              options={[
                { value: 'newest', label: 'Newest' },
                { value: 'applicants', label: 'Most Applicants' },
                { value: 'alphabetical', label: 'Alphabetical' },
              ]}
            />
          </div>
        </div>
        <JobList />
        <div className="px-4 py-3 bg-gray-50 text-right sm:px-6">
          <div className="flex items-center justify-between">
            <div className="text-sm text-gray-700">
              Showing <span className="font-medium">1</span> to <span className="font-medium">5</span> of <span className="font-medium">24</span> results
            </div>
            <div className="flex-1 flex justify-end">
              <Button variant="outline" className="mr-2" disabled>Previous</Button>
              <Button variant="outline">Next</Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobsPage;
