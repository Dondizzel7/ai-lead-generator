import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  jobs: [],
  selectedJob: null,
  loading: false,
  error: null,
  filters: {
    department: null,
    location: null,
    status: 'active'
  },
  pagination: {
    page: 1,
    limit: 10,
    total: 0
  }
};

export const jobsSlice = createSlice({
  name: 'jobs',
  initialState,
  reducers: {
    fetchJobsStart: (state) => {
      state.loading = true;
      state.error = null;
    },
    fetchJobsSuccess: (state, action) => {
      state.loading = false;
      state.jobs = action.payload.jobs;
      state.pagination.total = action.payload.total;
      state.error = null;
    },
    fetchJobsFailure: (state, action) => {
      state.loading = false;
      state.error = action.payload;
    },
    selectJob: (state, action) => {
      state.selectedJob = action.payload;
    },
    updateFilters: (state, action) => {
      state.filters = { ...state.filters, ...action.payload };
      state.pagination.page = 1; // Reset to first page when filters change
    },
    updatePagination: (state, action) => {
      state.pagination = { ...state.pagination, ...action.payload };
    },
    addJob: (state, action) => {
      state.jobs.unshift(action.payload);
      state.pagination.total += 1;
    },
    updateJob: (state, action) => {
      const index = state.jobs.findIndex(j => j.id === action.payload.id);
      if (index !== -1) {
        state.jobs[index] = action.payload;
        if (state.selectedJob && state.selectedJob.id === action.payload.id) {
          state.selectedJob = action.payload;
        }
      }
    },
    removeJob: (state, action) => {
      state.jobs = state.jobs.filter(j => j.id !== action.payload);
      state.pagination.total -= 1;
      if (state.selectedJob && state.selectedJob.id === action.payload) {
        state.selectedJob = null;
      }
    }
  }
});

export const {
  fetchJobsStart,
  fetchJobsSuccess,
  fetchJobsFailure,
  selectJob,
  updateFilters,
  updatePagination,
  addJob,
  updateJob,
  removeJob
} = jobsSlice.actions;

export default jobsSlice.reducer;
