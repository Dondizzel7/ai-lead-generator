import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  interviews: [],
  selectedInterview: null,
  loading: false,
  error: null,
  filters: {
    status: 'upcoming',
    candidateId: null,
    jobId: null,
    dateRange: null
  },
  pagination: {
    page: 1,
    limit: 10,
    total: 0
  }
};

export const interviewsSlice = createSlice({
  name: 'interviews',
  initialState,
  reducers: {
    fetchInterviewsStart: (state) => {
      state.loading = true;
      state.error = null;
    },
    fetchInterviewsSuccess: (state, action) => {
      state.loading = false;
      state.interviews = action.payload.interviews;
      state.pagination.total = action.payload.total;
      state.error = null;
    },
    fetchInterviewsFailure: (state, action) => {
      state.loading = false;
      state.error = action.payload;
    },
    selectInterview: (state, action) => {
      state.selectedInterview = action.payload;
    },
    updateFilters: (state, action) => {
      state.filters = { ...state.filters, ...action.payload };
      state.pagination.page = 1; // Reset to first page when filters change
    },
    updatePagination: (state, action) => {
      state.pagination = { ...state.pagination, ...action.payload };
    },
    scheduleInterview: (state, action) => {
      state.interviews.unshift(action.payload);
      state.pagination.total += 1;
    },
    updateInterview: (state, action) => {
      const index = state.interviews.findIndex(i => i.id === action.payload.id);
      if (index !== -1) {
        state.interviews[index] = action.payload;
        if (state.selectedInterview && state.selectedInterview.id === action.payload.id) {
          state.selectedInterview = action.payload;
        }
      }
    },
    cancelInterview: (state, action) => {
      const index = state.interviews.findIndex(i => i.id === action.payload);
      if (index !== -1) {
        state.interviews[index] = { 
          ...state.interviews[index], 
          status: 'cancelled',
          updatedAt: new Date().toISOString()
        };
        if (state.selectedInterview && state.selectedInterview.id === action.payload) {
          state.selectedInterview = { 
            ...state.selectedInterview, 
            status: 'cancelled',
            updatedAt: new Date().toISOString()
          };
        }
      }
    }
  }
});

export const {
  fetchInterviewsStart,
  fetchInterviewsSuccess,
  fetchInterviewsFailure,
  selectInterview,
  updateFilters,
  updatePagination,
  scheduleInterview,
  updateInterview,
  cancelInterview
} = interviewsSlice.actions;

export default interviewsSlice.reducer;
