import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  candidates: [],
  selectedCandidate: null,
  loading: false,
  error: null,
  filters: {
    skills: [],
    experience: null,
    location: null,
    jobId: null
  },
  pagination: {
    page: 1,
    limit: 10,
    total: 0
  }
};

export const candidatesSlice = createSlice({
  name: 'candidates',
  initialState,
  reducers: {
    fetchCandidatesStart: (state) => {
      state.loading = true;
      state.error = null;
    },
    fetchCandidatesSuccess: (state, action) => {
      state.loading = false;
      state.candidates = action.payload.candidates;
      state.pagination.total = action.payload.total;
      state.error = null;
    },
    fetchCandidatesFailure: (state, action) => {
      state.loading = false;
      state.error = action.payload;
    },
    selectCandidate: (state, action) => {
      state.selectedCandidate = action.payload;
    },
    updateFilters: (state, action) => {
      state.filters = { ...state.filters, ...action.payload };
      state.pagination.page = 1; // Reset to first page when filters change
    },
    updatePagination: (state, action) => {
      state.pagination = { ...state.pagination, ...action.payload };
    },
    addCandidate: (state, action) => {
      state.candidates.unshift(action.payload);
      state.pagination.total += 1;
    },
    updateCandidate: (state, action) => {
      const index = state.candidates.findIndex(c => c.id === action.payload.id);
      if (index !== -1) {
        state.candidates[index] = action.payload;
        if (state.selectedCandidate && state.selectedCandidate.id === action.payload.id) {
          state.selectedCandidate = action.payload;
        }
      }
    },
    removeCandidate: (state, action) => {
      state.candidates = state.candidates.filter(c => c.id !== action.payload);
      state.pagination.total -= 1;
      if (state.selectedCandidate && state.selectedCandidate.id === action.payload) {
        state.selectedCandidate = null;
      }
    }
  }
});

export const {
  fetchCandidatesStart,
  fetchCandidatesSuccess,
  fetchCandidatesFailure,
  selectCandidate,
  updateFilters,
  updatePagination,
  addCandidate,
  updateCandidate,
  removeCandidate
} = candidatesSlice.actions;

export default candidatesSlice.reducer;
