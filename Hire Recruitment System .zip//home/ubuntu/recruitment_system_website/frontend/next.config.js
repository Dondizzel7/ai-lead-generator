module.exports = {
  reactStrictMode: true,
  images: {
    domains: ['localhost', 'recruitment-system.com'],
  },
  env: {
    API_URL: process.env.API_URL || 'http://localhost:3001/api',
  },
  i18n: {
    locales: ['en'],
    defaultLocale: 'en',
  },
}
