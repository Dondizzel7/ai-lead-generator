#!/bin/bash

# Self-signed SSL certificate generation for development
# In production, replace with Let's Encrypt or other trusted certificates

# Set variables
DOMAIN="recruitment-system.com"
SSL_DIR="/home/ubuntu/recruitment_system_website/nginx/ssl"
DAYS_VALID=365

# Create SSL directory if it doesn't exist
mkdir -p $SSL_DIR

# Generate private key
openssl genrsa -out $SSL_DIR/$DOMAIN.key 2048

# Generate CSR (Certificate Signing Request)
openssl req -new -key $SSL_DIR/$DOMAIN.key -out $SSL_DIR/$DOMAIN.csr -subj "/C=US/ST=State/L=City/O=Organization/OU=Department/CN=$DOMAIN"

# Generate self-signed certificate
openssl x509 -req -days $DAYS_VALID -in $SSL_DIR/$DOMAIN.csr -signkey $SSL_DIR/$DOMAIN.key -out $SSL_DIR/$DOMAIN.crt

# Create .env file for environment variables
cat > /home/ubuntu/recruitment_system_website/.env << EOL
# Production environment variables
NODE_ENV=production

# Security
JWT_SECRET=replace_with_secure_random_string_in_production
ENCRYPTION_KEY=replace_with_secure_random_string_in_production

# API Keys
LINKEDIN_API_KEY=your_linkedin_api_key
GITHUB_API_KEY=your_github_api_key
STACKOVERFLOW_API_KEY=your_stackoverflow_api_key

# Calendar Integration
GOOGLE_CALENDAR_CLIENT_ID=your_google_client_id
GOOGLE_CALENDAR_CLIENT_SECRET=your_google_client_secret
MICROSOFT_CALENDAR_CLIENT_ID=your_microsoft_client_id
MICROSOFT_CALENDAR_CLIENT_SECRET=your_microsoft_client_secret

# Email Configuration
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_USER=your_smtp_username
SMTP_PASS=your_smtp_password
EMAIL_FROM=noreply@recruitment-system.com

# Storage Configuration
STORAGE_TYPE=local
S3_BUCKET=your_s3_bucket_name
S3_REGION=us-east-1
S3_ACCESS_KEY_ID=your_s3_access_key
S3_SECRET_ACCESS_KEY=your_s3_secret_key
EOL

echo "SSL certificates generated and environment file created successfully!"
