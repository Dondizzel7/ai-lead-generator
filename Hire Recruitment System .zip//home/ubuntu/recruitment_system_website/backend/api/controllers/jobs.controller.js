const Job = require('../../models/job.model');
const Candidate = require('../../models/candidate.model');

// Get all jobs with pagination and filtering
exports.getAllJobs = async (req, res) => {
  try {
    const { 
      page = 1, 
      limit = 10, 
      status, 
      department, 
      location,
      search,
      sortBy = 'createdAt',
      sortOrder = 'desc'
    } = req.query;
    
    // Build query
    const query = {};
    
    // Filter by status
    if (status) {
      query.status = status;
    }
    
    // Filter by department
    if (department) {
      query.department = department;
    }
    
    // Filter by location
    if (location) {
      query.location = location;
    }
    
    // Search by text
    if (search) {
      query.$text = { $search: search };
    }
    
    // Sort options
    const sort = {};
    sort[sortBy] = sortOrder === 'asc' ? 1 : -1;
    
    // Execute query with pagination
    const jobs = await Job.find(query)
      .sort(sort)
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .populate('hiringManager', 'firstName lastName email')
      .populate('recruiters', 'firstName lastName email')
      .exec();
    
    // Get total count
    const count = await Job.countDocuments(query);
    
    res.status(200).json({
      success: true,
      data: {
        jobs,
        totalPages: Math.ceil(count / limit),
        currentPage: page,
        totalJobs: count
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error retrieving jobs',
      error: error.message
    });
  }
};

// Get a single job by ID
exports.getJobById = async (req, res) => {
  try {
    const job = await Job.findById(req.params.id)
      .populate('hiringManager', 'firstName lastName email')
      .populate('recruiters', 'firstName lastName email')
      .populate('candidates.candidate', 'firstName lastName email skills');
    
    if (!job) {
      return res.status(404).json({
        success: false,
        message: 'Job not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: {
        job
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error retrieving job',
      error: error.message
    });
  }
};

// Create a new job
exports.createJob = async (req, res) => {
  try {
    const job = new Job({
      ...req.body,
      createdBy: req.user.id
    });
    
    await job.save();
    
    res.status(201).json({
      success: true,
      message: 'Job created successfully',
      data: {
        job
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error creating job',
      error: error.message
    });
  }
};

// Update a job
exports.updateJob = async (req, res) => {
  try {
    const job = await Job.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    
    if (!job) {
      return res.status(404).json({
        success: false,
        message: 'Job not found'
      });
    }
    
    res.status(200).json({
      success: true,
      message: 'Job updated successfully',
      data: {
        job
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error updating job',
      error: error.message
    });
  }
};

// Delete a job
exports.deleteJob = async (req, res) => {
  try {
    const job = await Job.findByIdAndDelete(req.params.id);
    
    if (!job) {
      return res.status(404).json({
        success: false,
        message: 'Job not found'
      });
    }
    
    res.status(200).json({
      success: true,
      message: 'Job deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error deleting job',
      error: error.message
    });
  }
};

// Get candidates matched to a job
exports.getJobCandidates = async (req, res) => {
  try {
    const jobId = req.params.id;
    
    const job = await Job.findById(jobId);
    if (!job) {
      return res.status(404).json({
        success: false,
        message: 'Job not found'
      });
    }
    
    // Find candidates with match scores for this job
    const candidates = await Candidate.find({
      'matchScores.job': jobId
    }).sort({ 'matchScores.score': -1 });
    
    // Format the response
    const formattedCandidates = candidates.map(candidate => {
      const matchScore = candidate.matchScores.find(
        score => score.job.toString() === jobId
      );
      
      return {
        _id: candidate._id,
        firstName: candidate.firstName,
        lastName: candidate.lastName,
        email: candidate.email,
        currentRole: candidate.currentRole,
        currentCompany: candidate.currentCompany,
        skills: candidate.skills,
        status: candidate.status,
        matchScore: matchScore ? matchScore.score : null,
        matchDetails: matchScore ? matchScore.details : null
      };
    });
    
    res.status(200).json({
      success: true,
      data: {
        candidates: formattedCandidates,
        totalCandidates: formattedCandidates.length
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error retrieving job candidates',
      error: error.message
    });
  }
};

// Auto-generate job description
exports.generateJobDescription = async (req, res) => {
  try {
    const { title, department, skills, responsibilities } = req.body;
    
    if (!title || !department) {
      return res.status(400).json({
        success: false,
        message: 'Title and department are required'
      });
    }
    
    // In a real implementation, this would:
    // 1. Connect to an AI service or LLM
    // 2. Generate a job description based on the provided information
    // 3. Format the response with sections for responsibilities, requirements, etc.
    
    // For demo purposes, we'll simulate the generated description
    const generatedDescription = {
      title,
      department,
      description: `We are seeking a talented ${title} to join our ${department} team. This role offers an exciting opportunity to work on cutting-edge projects in a collaborative environment.`,
      responsibilities: responsibilities || [
        `Design and develop solutions for our ${department} team`,
        "Collaborate with cross-functional teams to define requirements",
        "Implement best practices and standards"
      ],
      requirements: {
        required: [
          `${skills ? skills[0] : 'Relevant'} experience in ${department}`,
          "Bachelor's degree in a related field",
          "Strong problem-solving skills"
        ],
        preferred: [
          "Master's degree in a related field",
          "Experience with agile methodologies",
          "Excellent communication skills"
        ]
      }
    };
    
    res.status(200).json({
      success: true,
      message: 'Job description generated successfully',
      data: generatedDescription
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error generating job description',
      error: error.message
    });
  }
};

// Auto-optimize job requirements
exports.optimizeJobRequirements = async (req, res) => {
  try {
    const jobId = req.params.id;
    
    const job = await Job.findById(jobId);
    if (!job) {
      return res.status(404).json({
        success: false,
        message: 'Job not found'
      });
    }
    
    // In a real implementation, this would:
    // 1. Analyze the current job requirements
    // 2. Compare with successful hires in similar roles
    // 3. Identify requirements that might be too restrictive
    // 4. Suggest optimizations to increase candidate pool
    
    // For demo purposes, we'll simulate the optimization results
    const optimizationResults = {
      originalRequirements: job.requirements,
      optimizedRequirements: {
        required: job.requirements.required.map(req => req),
        preferred: [...job.requirements.preferred, "Experience with remote work"]
      },
      recommendations: [
        "Consider making some required skills preferred to widen candidate pool",
        "Add more specific technical skills to attract qualified candidates",
        "Include remote work experience as a preferred qualification"
      ],
      potentialImpact: {
        candidatePoolIncrease: "35%",
        timeToHireReduction: "20%"
      }
    };
    
    res.status(200).json({
      success: true,
      message: 'Job requirements optimized successfully',
      data: optimizationResults
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error optimizing job requirements',
      error: error.message
    });
  }
};
