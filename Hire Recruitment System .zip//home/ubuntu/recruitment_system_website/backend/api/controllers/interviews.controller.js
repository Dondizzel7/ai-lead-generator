const Interview = require('../../models/interview.model');
const Candidate = require('../../models/candidate.model');
const Job = require('../../models/job.model');

// Get all interviews with pagination and filtering
exports.getAllInterviews = async (req, res) => {
  try {
    const { 
      page = 1, 
      limit = 10, 
      status, 
      type, 
      date,
      search,
      sortBy = 'scheduledDate',
      sortOrder = 'asc'
    } = req.query;
    
    // Build query
    const query = {};
    
    // Filter by status
    if (status) {
      query.status = status;
    }
    
    // Filter by type
    if (type) {
      query.type = type;
    }
    
    // Filter by date
    if (date) {
      const startDate = new Date(date);
      startDate.setHours(0, 0, 0, 0);
      
      const endDate = new Date(date);
      endDate.setHours(23, 59, 59, 999);
      
      query.scheduledDate = { $gte: startDate, $lte: endDate };
    }
    
    // Sort options
    const sort = {};
    sort[sortBy] = sortOrder === 'asc' ? 1 : -1;
    
    // Execute query with pagination
    const interviews = await Interview.find(query)
      .sort(sort)
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .populate('candidate', 'firstName lastName email currentRole')
      .populate('job', 'title department location')
      .populate('interviewers', 'firstName lastName email')
      .exec();
    
    // Get total count
    const count = await Interview.countDocuments(query);
    
    res.status(200).json({
      success: true,
      data: {
        interviews,
        totalPages: Math.ceil(count / limit),
        currentPage: page,
        totalInterviews: count
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error retrieving interviews',
      error: error.message
    });
  }
};

// Get a single interview by ID
exports.getInterviewById = async (req, res) => {
  try {
    const interview = await Interview.findById(req.params.id)
      .populate('candidate', 'firstName lastName email currentRole currentCompany')
      .populate('job', 'title department location')
      .populate('interviewers', 'firstName lastName email')
      .populate('createdBy', 'firstName lastName');
    
    if (!interview) {
      return res.status(404).json({
        success: false,
        message: 'Interview not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: {
        interview
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error retrieving interview',
      error: error.message
    });
  }
};

// Create a new interview
exports.createInterview = async (req, res) => {
  try {
    const { candidate: candidateId, job: jobId } = req.body;
    
    // Verify candidate exists
    const candidate = await Candidate.findById(candidateId);
    if (!candidate) {
      return res.status(404).json({
        success: false,
        message: 'Candidate not found'
      });
    }
    
    // Verify job exists
    const job = await Job.findById(jobId);
    if (!job) {
      return res.status(404).json({
        success: false,
        message: 'Job not found'
      });
    }
    
    const interview = new Interview({
      ...req.body,
      createdBy: req.user.id
    });
    
    await interview.save();
    
    // Update candidate status if needed
    if (candidate.status === 'screening' || candidate.status === 'sourced') {
      candidate.status = 'interview';
      await candidate.save();
    }
    
    // Add interview to job's interviews array
    job.interviews.push(interview._id);
    await job.save();
    
    res.status(201).json({
      success: true,
      message: 'Interview created successfully',
      data: {
        interview
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error creating interview',
      error: error.message
    });
  }
};

// Update an interview
exports.updateInterview = async (req, res) => {
  try {
    const interview = await Interview.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    
    if (!interview) {
      return res.status(404).json({
        success: false,
        message: 'Interview not found'
      });
    }
    
    res.status(200).json({
      success: true,
      message: 'Interview updated successfully',
      data: {
        interview
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error updating interview',
      error: error.message
    });
  }
};

// Delete an interview
exports.deleteInterview = async (req, res) => {
  try {
    const interview = await Interview.findByIdAndDelete(req.params.id);
    
    if (!interview) {
      return res.status(404).json({
        success: false,
        message: 'Interview not found'
      });
    }
    
    // Remove interview from job's interviews array
    await Job.findByIdAndUpdate(interview.job, {
      $pull: { interviews: interview._id }
    });
    
    res.status(200).json({
      success: true,
      message: 'Interview deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error deleting interview',
      error: error.message
    });
  }
};

// Auto-schedule interview
exports.autoScheduleInterview = async (req, res) => {
  try {
    const { 
      candidateId, 
      jobId, 
      interviewerIds, 
      duration = 60,
      type = 'technical',
      location = 'video',
      preferredDates = []
    } = req.body;
    
    // Verify candidate exists
    const candidate = await Candidate.findById(candidateId);
    if (!candidate) {
      return res.status(404).json({
        success: false,
        message: 'Candidate not found'
      });
    }
    
    // Verify job exists
    const job = await Job.findById(jobId);
    if (!job) {
      return res.status(404).json({
        success: false,
        message: 'Job not found'
      });
    }
    
    // In a real implementation, this would:
    // 1. Connect to the scheduling system module
    // 2. Check availability of all interviewers
    // 3. Find optimal time slots based on constraints
    // 4. Create calendar events and send invitations
    
    // For demo purposes, we'll simulate the scheduling results
    const now = new Date();
    const scheduledDate = new Date(now.setDate(now.getDate() + 3));
    scheduledDate.setHours(10, 0, 0, 0); // 10:00 AM
    
    const interview = new Interview({
      candidate: candidateId,
      job: jobId,
      type,
      scheduledDate,
      duration,
      location,
      interviewers: interviewerIds,
      meetingLink: 'https://meet.google.com/abc-defg-hij',
      status: 'scheduled',
      createdBy: req.user.id
    });
    
    await interview.save();
    
    // Update candidate status
    if (candidate.status === 'screening' || candidate.status === 'sourced') {
      candidate.status = 'interview';
      await candidate.save();
    }
    
    // Add interview to job's interviews array
    job.interviews.push(interview._id);
    await job.save();
    
    res.status(201).json({
      success: true,
      message: 'Interview auto-scheduled successfully',
      data: {
        interview,
        scheduledDate: scheduledDate.toISOString()
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error auto-scheduling interview',
      error: error.message
    });
  }
};

// Generate interview questions
exports.generateInterviewQuestions = async (req, res) => {
  try {
    const interviewId = req.params.id;
    
    const interview = await Interview.findById(interviewId)
      .populate('candidate', 'skills experience education')
      .populate('job', 'title department skills requirements');
    
    if (!interview) {
      return res.status(404).json({
        success: false,
        message: 'Interview not found'
      });
    }
    
    // In a real implementation, this would:
    // 1. Connect to the question generation AI module
    // 2. Analyze the candidate profile and job requirements
    // 3. Generate tailored questions based on the interview type
    
    // For demo purposes, we'll simulate the generated questions
    const questionTypes = {
      technical: [
        {
          question: "Explain the difference between REST and GraphQL APIs.",
          type: "technical",
          expectedAnswer: "REST uses multiple endpoints with fixed data structures, while GraphQL uses a single endpoint with flexible queries.",
          importance: 4
        },
        {
          question: "How would you optimize a slow database query?",
          type: "technical",
          expectedAnswer: "Check indexes, analyze query execution plan, optimize joins, consider caching.",
          importance: 5
        },
        {
          question: "Describe your experience with containerization technologies.",
          type: "technical",
          expectedAnswer: "Experience with Docker, Kubernetes, container orchestration, and deployment strategies.",
          importance: 3
        }
      ],
      behavioral: [
        {
          question: "Tell me about a time when you had to meet a tight deadline.",
          type: "behavioral",
          expectedAnswer: "Looking for prioritization skills, teamwork, and stress management.",
          importance: 4
        },
        {
          question: "Describe a situation where you had to resolve a conflict within your team.",
          type: "behavioral",
          expectedAnswer: "Looking for communication skills, empathy, and problem-solving approach.",
          importance: 3
        },
        {
          question: "How do you stay updated with the latest technologies in your field?",
          type: "behavioral",
          expectedAnswer: "Looking for continuous learning habits, curiosity, and professional development.",
          importance: 4
        }
      ],
      situational: [
        {
          question: "How would you handle a situation where requirements change mid-project?",
          type: "situational",
          expectedAnswer: "Looking for adaptability, communication with stakeholders, and prioritization skills.",
          importance: 4
        },
        {
          question: "What would you do if you discovered a critical bug in production code?",
          type: "situational",
          expectedAnswer: "Looking for problem-solving approach, communication, and responsibility.",
          importance: 5
        }
      ]
    };
    
    // Select questions based on interview type
    let generatedQuestions = [];
    
    if (interview.type === 'technical') {
      generatedQuestions = [
        ...questionTypes.technical,
        ...questionTypes.situational.slice(0, 1)
      ];
    } else if (interview.type === 'behavioral') {
      generatedQuestions = [
        ...questionTypes.behavioral,
        ...questionTypes.situational.slice(0, 1)
      ];
    } else {
      // For other types, mix questions
      generatedQuestions = [
        ...questionTypes.technical.slice(0, 2),
        ...questionTypes.behavioral.slice(0, 2),
        ...questionTypes.situational.slice(0, 1)
      ];
    }
    
    // Update interview with generated questions
    interview.questions = generatedQuestions;
    await interview.save();
    
    res.status(200).json({
      success: true,
      message: 'Interview questions generated successfully',
      data: {
        questions: generatedQuestions
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error generating interview questions',
      error: error.message
    });
  }
};

// Analyze interview responses
exports.analyzeInterviewResponses = async (req, res) => {
  try {
    const interviewId = req.params.id;
    const { responses } = req.body;
    
    if (!responses || !Array.isArray(responses)) {
      return res.status(400).json({
        success: false,
        message: 'Responses must be provided as an array'
      });
    }
    
    const interview = await Interview.findById(interviewId);
    if (!interview) {
      return res.status(404).json({
        success: false,
        message: 'Interview not found'
      });
    }
    
    // In a real implementation, this would:
    // 1. Connect to the response analysis AI module
    // 2. Analyze each response against expected answers
    // 3. Evaluate technical accuracy, communication skills, etc.
    // 4. Generate an overall evaluation
    
    // For demo purposes, we'll simulate the analysis results
    const evaluation = {
      technicalSkills: {
        score: 4.2,
        comments: "Strong technical knowledge with good understanding of system design principles."
      },
      communicationSkills: {
        score: 3.8,
        comments: "Clear communication with room for improvement in explaining complex concepts."
      },
      problemSolving: {
        score: 4.5,
        comments: "Excellent problem-solving approach with systematic thinking."
      },
      culturalFit: {
        score: 4.0,
        comments: "Values align well with company culture, shows collaborative mindset."
      },
      overallRating: {
        score: 4.1,
        comments: "Strong candidate with solid technical skills and good cultural fit."
      },
      recommendation: "hire",
      submittedBy: req.user.id,
      submittedAt: new Date()
    };
    
    // Update interview with evaluation
    interview.evaluation = evaluation;
    interview.status = 'completed';
    await interview.save();
    
    // Update candidate status if this was the final interview
    const candidate = await Candidate.findById(interview.candidate);
    if (candidate && candidate.status === 'interview') {
      if (evaluation.recommendation === 'strong_hire' || evaluation.recommendation === 'hire') {
        candidate.status = 'offer';
        await candidate.save();
      }
    }
    
    res.status(200).json({
      success: true,
      message: 'Interview responses analyzed successfully',
      data: {
        evaluation
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error analyzing interview responses',
      error: error.message
    });
  }
};

// Get available time slots
exports.getAvailableTimeSlots = async (req, res) => {
  try {
    const { 
      interviewerIds, 
      candidateId,
      startDate,
      endDate,
      duration = 60
    } = req.query;
    
    if (!interviewerIds) {
      return res.status(400).json({
        success: false,
        message: 'Interviewer IDs are required'
      });
    }
    
    // In a real implementation, this would:
    // 1. Connect to the scheduling system module
    // 2. Check calendar availability for all interviewers
    // 3. Find common available time slots
    // 4. Return formatted time slots
    
    // For demo purposes, we'll simulate available time slots
    const now = new Date();
    const slots = [];
    
    // Generate slots for the next 5 business days
    for (let i = 1; i <= 5; i++) {
      const date = new Date(now);
      date.setDate(date.getDate() + i);
      
      // Skip weekends
      if (date.getDay() === 0 || date.getDay() === 6) {
        continue;
      }
      
      // Morning slots
      for (let hour = 9; hour < 12; hour++) {
        const slot = new Date(date);
        slot.setHours(hour, 0, 0, 0);
        
        slots.push({
          startTime: slot.toISOString(),
          endTime: new Date(slot.getTime() + duration * 60000).toISOString(),
          available: true
        });
      }
      
      // Afternoon slots
      for (let hour = 13; hour < 17; hour++) {
        const slot = new Date(date);
        slot.setHours(hour, 0, 0, 0);
        
        slots.push({
          startTime: slot.toISOString(),
          endTime: new Date(slot.getTime() + <response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>