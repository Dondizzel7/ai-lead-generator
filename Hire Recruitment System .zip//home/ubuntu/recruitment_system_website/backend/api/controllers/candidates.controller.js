const Candidate = require('../../models/candidate.model');
const Job = require('../../models/job.model');

// Get all candidates with pagination and filtering
exports.getAllCandidates = async (req, res) => {
  try {
    const { 
      page = 1, 
      limit = 10, 
      status, 
      skills, 
      search,
      sortBy = 'createdAt',
      sortOrder = 'desc'
    } = req.query;
    
    // Build query
    const query = {};
    
    // Filter by status
    if (status) {
      query.status = status;
    }
    
    // Filter by skills
    if (skills) {
      const skillsArray = skills.split(',');
      query.skills = { $in: skillsArray };
    }
    
    // Search by text
    if (search) {
      query.$text = { $search: search };
    }
    
    // Sort options
    const sort = {};
    sort[sortBy] = sortOrder === 'asc' ? 1 : -1;
    
    // Execute query with pagination
    const candidates = await Candidate.find(query)
      .sort(sort)
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .exec();
    
    // Get total count
    const count = await Candidate.countDocuments(query);
    
    res.status(200).json({
      success: true,
      data: {
        candidates,
        totalPages: Math.ceil(count / limit),
        currentPage: page,
        totalCandidates: count
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error retrieving candidates',
      error: error.message
    });
  }
};

// Get a single candidate by ID
exports.getCandidateById = async (req, res) => {
  try {
    const candidate = await Candidate.findById(req.params.id);
    
    if (!candidate) {
      return res.status(404).json({
        success: false,
        message: 'Candidate not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: {
        candidate
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error retrieving candidate',
      error: error.message
    });
  }
};

// Create a new candidate
exports.createCandidate = async (req, res) => {
  try {
    const candidate = new Candidate({
      ...req.body,
      createdBy: req.user.id
    });
    
    await candidate.save();
    
    res.status(201).json({
      success: true,
      message: 'Candidate created successfully',
      data: {
        candidate
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error creating candidate',
      error: error.message
    });
  }
};

// Update a candidate
exports.updateCandidate = async (req, res) => {
  try {
    const candidate = await Candidate.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    
    if (!candidate) {
      return res.status(404).json({
        success: false,
        message: 'Candidate not found'
      });
    }
    
    res.status(200).json({
      success: true,
      message: 'Candidate updated successfully',
      data: {
        candidate
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error updating candidate',
      error: error.message
    });
  }
};

// Delete a candidate
exports.deleteCandidate = async (req, res) => {
  try {
    const candidate = await Candidate.findByIdAndDelete(req.params.id);
    
    if (!candidate) {
      return res.status(404).json({
        success: false,
        message: 'Candidate not found'
      });
    }
    
    res.status(200).json({
      success: true,
      message: 'Candidate deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error deleting candidate',
      error: error.message
    });
  }
};

// Source candidates automatically
exports.sourceCandidates = async (req, res) => {
  try {
    const { jobId, source, keywords, location, count = 10 } = req.body;
    
    // In a real implementation, this would:
    // 1. Connect to the sourcing AI module
    // 2. Call the appropriate data collector (LinkedIn, GitHub, etc.)
    // 3. Process and filter the results
    // 4. Create candidate records
    
    // For demo purposes, we'll simulate the response
    const sourcedCandidates = {
      total: count,
      source: source || 'linkedin',
      candidates: []
    };
    
    res.status(200).json({
      success: true,
      message: `Successfully sourced ${count} candidates`,
      data: sourcedCandidates
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error sourcing candidates',
      error: error.message
    });
  }
};

// Screen candidate resume
exports.screenCandidate = async (req, res) => {
  try {
    const candidateId = req.params.id;
    
    const candidate = await Candidate.findById(candidateId);
    if (!candidate) {
      return res.status(404).json({
        success: false,
        message: 'Candidate not found'
      });
    }
    
    // In a real implementation, this would:
    // 1. Connect to the screening AI module
    // 2. Process the resume
    // 3. Extract and verify skills, experience, education
    // 4. Generate a screening score and recommendations
    
    // For demo purposes, we'll simulate the screening results
    const screeningResults = {
      resumeQuality: 85,
      skillsVerified: candidate.skills.slice(0, 5),
      experienceVerified: true,
      educationVerified: true,
      overallScore: 82,
      recommendations: "Strong technical background with relevant experience. Recommend proceeding to technical interview."
    };
    
    // Update candidate with screening results
    candidate.screeningResults = screeningResults;
    candidate.status = 'screening';
    await candidate.save();
    
    res.status(200).json({
      success: true,
      message: 'Candidate resume screened successfully',
      data: {
        screeningResults
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error screening candidate resume',
      error: error.message
    });
  }
};

// Match candidate to job
exports.matchCandidateToJob = async (req, res) => {
  try {
    const candidateId = req.params.id;
    const jobId = req.params.jobId;
    
    const candidate = await Candidate.findById(candidateId);
    if (!candidate) {
      return res.status(404).json({
        success: false,
        message: 'Candidate not found'
      });
    }
    
    const job = await Job.findById(jobId);
    if (!job) {
      return res.status(404).json({
        success: false,
        message: 'Job not found'
      });
    }
    
    // In a real implementation, this would:
    // 1. Connect to the matching AI module
    // 2. Compare candidate skills, experience, education to job requirements
    // 3. Generate match scores for different categories
    // 4. Calculate an overall match percentage
    
    // For demo purposes, we'll simulate the matching results
    const matchDetails = {
      skillsMatch: 85,
      experienceMatch: 90,
      educationMatch: 75,
      overallMatch: 87
    };
    
    // Check if candidate already has a match score for this job
    const existingMatchIndex = candidate.matchScores.findIndex(
      match => match.job.toString() === jobId
    );
    
    if (existingMatchIndex !== -1) {
      // Update existing match score
      candidate.matchScores[existingMatchIndex].score = matchDetails.overallMatch;
      candidate.matchScores[existingMatchIndex].details = matchDetails;
    } else {
      // Add new match score
      candidate.matchScores.push({
        job: jobId,
        score: matchDetails.overallMatch,
        details: matchDetails
      });
    }
    
    await candidate.save();
    
    res.status(200).json({
      success: true,
      message: 'Candidate matched to job successfully',
      data: {
        matchDetails,
        overallMatch: matchDetails.overallMatch
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error matching candidate to job',
      error: error.message
    });
  }
};
