const express = require('express');
const router = express.Router();
const interviewsController = require('../controllers/interviews.controller');
const { authMiddleware } = require('../../middleware/auth.middleware');

// All routes require authentication
router.use(authMiddleware);

// Get all interviews with pagination and filtering
router.get('/', interviewsController.getAllInterviews);

// Get a single interview by ID
router.get('/:id', interviewsController.getInterviewById);

// Create a new interview
router.post('/', interviewsController.createInterview);

// Update an interview
router.put('/:id', interviewsController.updateInterview);

// Delete an interview
router.delete('/:id', interviewsController.deleteInterview);

// Auto-schedule interview
router.post('/auto-schedule', interviewsController.autoScheduleInterview);

// Generate interview questions
router.post('/:id/generate-questions', interviewsController.generateInterviewQuestions);

// Analyze interview responses
router.post('/:id/analyze-responses', interviewsController.analyzeInterviewResponses);

// Get available time slots
router.get('/available-slots', interviewsController.getAvailableTimeSlots);

module.exports = router;
