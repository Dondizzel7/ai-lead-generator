const express = require('express');
const router = express.Router();
const candidatesController = require('../controllers/candidates.controller');
const { authMiddleware } = require('../../middleware/auth.middleware');

// All routes require authentication
router.use(authMiddleware);

// Get all candidates with pagination and filtering
router.get('/', candidatesController.getAllCandidates);

// Get a single candidate by ID
router.get('/:id', candidatesController.getCandidateById);

// Create a new candidate
router.post('/', candidatesController.createCandidate);

// Update a candidate
router.put('/:id', candidatesController.updateCandidate);

// Delete a candidate
router.delete('/:id', candidatesController.deleteCandidate);

// Source candidates automatically
router.post('/source', candidatesController.sourceCandidates);

// Screen candidate resume
router.post('/:id/screen', candidatesController.screenCandidate);

// Match candidate to job
router.post('/:id/match/:jobId', candidatesController.matchCandidateToJob);

module.exports = router;
