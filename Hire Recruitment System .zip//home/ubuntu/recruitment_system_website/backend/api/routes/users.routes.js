const express = require('express');
const router = express.Router();
const usersController = require('../controllers/users.controller');
const { authMiddleware } = require('../../middleware/auth.middleware');

// All routes require authentication
router.use(authMiddleware);

// Get all users (admin only)
router.get('/', usersController.getAllUsers);

// Get a single user by ID
router.get('/:id', usersController.getUserById);

// Create a new user (admin only)
router.post('/', usersController.createUser);

// Update a user
router.put('/:id', usersController.updateUser);

// Delete a user (admin only)
router.delete('/:id', usersController.deleteUser);

// Update user profile
router.put('/profile/update', usersController.updateProfile);

// Change password
router.put('/password/change', usersController.changePassword);

module.exports = router;
