const express = require('express');
const router = express.Router();
const jobsController = require('../controllers/jobs.controller');
const { authMiddleware } = require('../../middleware/auth.middleware');

// All routes require authentication
router.use(authMiddleware);

// Get all jobs with pagination and filtering
router.get('/', jobsController.getAllJobs);

// Get a single job by ID
router.get('/:id', jobsController.getJobById);

// Create a new job
router.post('/', jobsController.createJob);

// Update a job
router.put('/:id', jobsController.updateJob);

// Delete a job
router.delete('/:id', jobsController.deleteJob);

// Get candidates matched to a job
router.get('/:id/candidates', jobsController.getJobCandidates);

// Auto-generate job description
router.post('/generate-description', jobsController.generateJobDescription);

// Auto-optimize job requirements
router.post('/:id/optimize', jobsController.optimizeJobRequirements);

module.exports = router;
