const mongoose = require('mongoose');

const jobSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true
  },
  department: {
    type: String,
    required: true,
    trim: true
  },
  location: {
    type: String,
    required: true,
    trim: true
  },
  type: {
    type: String,
    enum: ['full-time', 'part-time', 'contract', 'internship'],
    default: 'full-time'
  },
  description: {
    type: String,
    required: true
  },
  responsibilities: [{
    type: String,
    trim: true
  }],
  requirements: {
    required: [{
      type: String,
      trim: true
    }],
    preferred: [{
      type: String,
      trim: true
    }]
  },
  skills: [{
    name: String,
    importance: {
      type: Number,
      min: 1,
      max: 5,
      default: 3
    }
  }],
  salary: {
    min: Number,
    max: Number,
    currency: {
      type: String,
      default: 'USD'
    }
  },
  status: {
    type: String,
    enum: ['draft', 'active', 'paused', 'closed', 'filled'],
    default: 'draft'
  },
  applicationDeadline: {
    type: Date
  },
  hiringManager: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  recruiters: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  candidates: [{
    candidate: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Candidate'
    },
    status: {
      type: String,
      enum: ['sourced', 'screening', 'interview', 'offer', 'hired', 'rejected'],
      default: 'sourced'
    },
    matchScore: Number,
    appliedDate: Date
  }],
  interviews: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Interview'
  }],
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  }
}, {
  timestamps: true
});

// Index for text search
jobSchema.index({ 
  title: 'text', 
  department: 'text', 
  location: 'text',
  description: 'text'
});

const Job = mongoose.model('Job', jobSchema);

module.exports = Job;
