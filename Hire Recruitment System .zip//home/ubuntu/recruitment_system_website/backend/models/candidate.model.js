const mongoose = require('mongoose');

const candidateSchema = new mongoose.Schema({
  firstName: {
    type: String,
    required: true,
    trim: true
  },
  lastName: {
    type: String,
    required: true,
    trim: true
  },
  email: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    lowercase: true
  },
  phone: {
    type: String,
    trim: true
  },
  location: {
    type: String,
    trim: true
  },
  currentRole: {
    type: String,
    trim: true
  },
  currentCompany: {
    type: String,
    trim: true
  },
  linkedInUrl: {
    type: String,
    trim: true
  },
  githubUrl: {
    type: String,
    trim: true
  },
  portfolioUrl: {
    type: String,
    trim: true
  },
  resumeUrl: {
    type: String
  },
  skills: [{
    type: String,
    trim: true
  }],
  experience: [{
    title: String,
    company: String,
    location: String,
    startDate: Date,
    endDate: Date,
    current: Boolean,
    description: String
  }],
  education: [{
    institution: String,
    degree: String,
    field: String,
    startDate: Date,
    endDate: Date,
    current: Boolean
  }],
  status: {
    type: String,
    enum: ['sourced', 'screening', 'interview', 'offer', 'hired', 'rejected'],
    default: 'sourced'
  },
  source: {
    type: String,
    enum: ['linkedin', 'github', 'stackoverflow', 'referral', 'application', 'other'],
    required: true
  },
  notes: [{
    content: String,
    author: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    createdAt: {
      type: Date,
      default: Date.now
    }
  }],
  tags: [{
    type: String,
    trim: true
  }],
  matchScores: [{
    job: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Job'
    },
    score: Number,
    details: {
      skillsMatch: Number,
      experienceMatch: Number,
      educationMatch: Number,
      overallMatch: Number
    }
  }],
  screeningResults: {
    resumeQuality: Number,
    skillsVerified: [String],
    experienceVerified: Boolean,
    educationVerified: Boolean,
    overallScore: Number,
    recommendations: String
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
}, {
  timestamps: true
});

// Index for text search
candidateSchema.index({ 
  firstName: 'text', 
  lastName: 'text', 
  currentRole: 'text',
  currentCompany: 'text',
  skills: 'text'
});

const Candidate = mongoose.model('Candidate', candidateSchema);

module.exports = Candidate;
