const mongoose = require('mongoose');

const interviewSchema = new mongoose.Schema({
  candidate: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Candidate',
    required: true
  },
  job: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Job',
    required: true
  },
  type: {
    type: String,
    enum: ['screening', 'technical', 'behavioral', 'panel', 'final'],
    required: true
  },
  scheduledDate: {
    type: Date,
    required: true
  },
  duration: {
    type: Number, // in minutes
    required: true,
    default: 60
  },
  location: {
    type: String,
    enum: ['onsite', 'video', 'phone'],
    required: true
  },
  meetingLink: {
    type: String,
    trim: true
  },
  interviewers: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  status: {
    type: String,
    enum: ['scheduled', 'completed', 'cancelled', 'rescheduled'],
    default: 'scheduled'
  },
  questions: [{
    question: String,
    type: {
      type: String,
      enum: ['technical', 'behavioral', 'situational']
    },
    expectedAnswer: String,
    importance: {
      type: Number,
      min: 1,
      max: 5,
      default: 3
    }
  }],
  evaluation: {
    technicalSkills: {
      score: Number,
      comments: String
    },
    communicationSkills: {
      score: Number,
      comments: String
    },
    problemSolving: {
      score: Number,
      comments: String
    },
    culturalFit: {
      score: Number,
      comments: String
    },
    overallRating: {
      score: Number,
      comments: String
    },
    recommendation: {
      type: String,
      enum: ['strong_hire', 'hire', 'neutral', 'no_hire', 'strong_no_hire']
    },
    submittedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    submittedAt: Date
  },
  notes: [{
    content: String,
    author: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    createdAt: {
      type: Date,
      default: Date.now
    }
  }],
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  }
}, {
  timestamps: true
});

const Interview = mongoose.model('Interview', interviewSchema);

module.exports = Interview;
