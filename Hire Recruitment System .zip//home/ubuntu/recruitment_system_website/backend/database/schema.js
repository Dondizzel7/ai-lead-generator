// MongoDB database schema for the recruitment system

// Database configuration
const dbConfig = {
  name: "recruitment_system_db",
  collections: [
    "users",
    "candidates",
    "jobs",
    "interviews",
    "offers",
    "onboarding_plans",
    "companies",
    "analytics"
  ],
  security: {
    encryption: true,
    accessControl: true,
    auditLogging: true,
    dataBackup: true
  }
};

// User schema
const userSchema = {
  _id: "ObjectId",
  email: "String (unique, required)",
  password: "String (hashed, required)",
  firstName: "String (required)",
  lastName: "String (required)",
  role: "String (enum: admin, recruiter, hiring_manager, interviewer)",
  company: "ObjectId (ref: companies)",
  phone: "String",
  profileImage: "String",
  department: "String",
  position: "String",
  isActive: "Boolean (default: true)",
  lastLogin: "Date",
  createdAt: "Date",
  updatedAt: "Date",
  settings: {
    notifications: {
      email: "Boolean (default: true)",
      inApp: "Boolean (default: true)",
      sms: "Boolean (default: false)"
    },
    timezone: "String (default: UTC)",
    language: "String (default: en)"
  },
  calendarIntegration: {
    provider: "String (enum: google, microsoft, none)",
    connected: "Boolean (default: false)",
    refreshToken: "String (encrypted)",
    calendarId: "String"
  },
  indexes: [
    { email: 1 },
    { company: 1 }
  ],
  security: {
    accessControl: {
      admin: "full",
      recruiter: "limited",
      hiring_manager: "limited",
      interviewer: "restricted"
    }
  }
};

// Candidate schema
const candidateSchema = {
  _id: "ObjectId",
  firstName: "String (required)",
  lastName: "String (required)",
  email: "String (required)",
  phone: "String",
  location: {
    city: "String",
    state: "String",
    country: "String",
    remote: "Boolean"
  },
  profileImage: "String",
  resumeUrl: "String",
  linkedinUrl: "String",
  githubUrl: "String",
  portfolioUrl: "String",
  source: "String (enum: linkedin, github, stackoverflow, referral, application, other)",
  skills: [{
    name: "String",
    level: "Number (1-5)",
    yearsOfExperience: "Number",
    verified: "Boolean"
  }],
  experience: [{
    company: "String",
    title: "String",
    location: "String",
    startDate: "Date",
    endDate: "Date",
    current: "Boolean",
    description: "String",
    verified: "Boolean"
  }],
  education: [{
    institution: "String",
    degree: "String",
    field: "String",
    startDate: "Date",
    endDate: "Date",
    verified: "Boolean"
  }],
  certifications: [{
    name: "String",
    issuer: "String",
    dateObtained: "Date",
    expiryDate: "Date",
    verified: "Boolean"
  }],
  status: "String (enum: new, screening, interviewing, offer, hired, rejected, archived)",
  currentSalary: {
    amount: "Number",
    currency: "String",
    confidential: "Boolean"
  },
  expectedSalary: {
    amount: "Number",
    currency: "String"
  },
  availability: {
    immediate: "Boolean",
    noticePeriod: "Number (days)"
  },
  notes: [{
    content: "String",
    author: "ObjectId (ref: users)",
    createdAt: "Date"
  }],
  tags: ["String"],
  aiMatchScore: "Number (0-100)",
  aiInsights: {
    strengths: ["String"],
    weaknesses: ["String"],
    fitScore: "Number (0-100)",
    potentialRoles: ["String"]
  },
  backgroundCheck: {
    status: "String (enum: not_started, in_progress, completed, failed)",
    completedAt: "Date",
    results: {
      criminal: "Boolean",
      employment: "Boolean",
      education: "Boolean",
      identity: "Boolean"
    }
  },
  createdBy: "ObjectId (ref: users)",
  company: "ObjectId (ref: companies)",
  createdAt: "Date",
  updatedAt: "Date",
  indexes: [
    { email: 1 },
    { skills: 1 },
    { status: 1 },
    { company: 1 },
    { aiMatchScore: -1 }
  ],
  security: {
    encryption: {
      fields: ["phone", "currentSalary", "notes"]
    }
  }
};

// Job schema
const jobSchema = {
  _id: "ObjectId",
  title: "String (required)",
  company: "ObjectId (ref: companies)",
  department: "String",
  location: {
    city: "String",
    state: "String",
    country: "String",
    remote: "Boolean"
  },
  type: "String (enum: full_time, part_time, contract, temporary, internship)",
  description: "String (required)",
  responsibilities: ["String"],
  requirements: {
    essential: ["String"],
    preferred: ["String"]
  },
  skills: [{
    name: "String",
    level: "Number (1-5)",
    importance: "Number (1-5)"
  }],
  experience: {
    minYears: "Number",
    level: "String (enum: entry, mid, senior, executive)"
  },
  education: {
    degree: "String",
    field: "String",
    required: "Boolean"
  },
  salary: {
    min: "Number",
    max: "Number",
    currency: "String",
    visible: "Boolean"
  },
  benefits: ["String"],
  status: "String (enum: draft, open, paused, closed, filled)",
  applicationDeadline: "Date",
  hiringManager: "ObjectId (ref: users)",
  recruiters: ["ObjectId (ref: users)"],
  interviewProcess: [{
    stage: "String",
    description: "String",
    interviewers: ["ObjectId (ref: users)"]
  }],
  candidateProgress: [{
    candidate: "ObjectId (ref: candidates)",
    stage: "String",
    status: "String (enum: active, passed, failed)",
    notes: "String"
  }],
  aiSettings: {
    autoSourceCandidates: "Boolean",
    autoScreenResumes: "Boolean",
    autoScheduleInterviews: "Boolean",
    matchThreshold: "Number (0-100)"
  },
  analytics: {
    views: "Number",
    applications: "Number",
    sourcedCandidates: "Number",
    interviewsScheduled: "Number",
    offersExtended: "Number",
    timeToFill: "Number (days)"
  },
  createdBy: "ObjectId (ref: users)",
  createdAt: "Date",
  updatedAt: "Date",
  indexes: [
    { title: 1 },
    { company: 1 },
    { status: 1 },
    { skills: 1 }
  ]
};

// Interview schema
const interviewSchema = {
  _id: "ObjectId",
  candidate: "ObjectId (ref: candidates)",
  job: "ObjectId (ref: jobs)",
  company: "ObjectId (ref: companies)",
  type: "String (enum: phone_screen, technical, behavioral, case_study, panel, final)",
  scheduledTime: {
    start: "Date",
    end: "Date"
  },
  location: {
    type: "String (enum: in_person, video, phone)",
    details: "String"
  },
  interviewers: [{
    user: "ObjectId (ref: users)",
    role: "String",
    confirmed: "Boolean"
  }],
  questions: [{
    text: "String",
    type: "String (enum: technical, behavioral, situational)",
    expectedAnswer: "String",
    importance: "Number (1-5)"
  }],
  feedback: [{
    interviewer: "ObjectId (ref: users)",
    rating: "Number (1-5)",
    strengths: ["String"],
    weaknesses: ["String"],
    notes: "String",
    recommendation: "String (enum: strong_hire, hire, neutral, no_hire, strong_no_hire)",
    submittedAt: "Date"
  }],
  aiAnalysis: {
    technicalScore: "Number (0-100)",
    communicationScore: "Number (0-100)",
    culturalFitScore: "Number (0-100)",
    overallScore: "Number (0-100)",
    strengths: ["String"],
    weaknesses: ["String"],
    recommendation: "String (enum: strong_hire, hire, neutral, no_hire, strong_no_hire)"
  },
  status: "String (enum: scheduled, completed, cancelled, no_show, rescheduled)",
  calendarEventId: "String",
  meetingLink: "String",
  recordingUrl: "String",
  notes: "String",
  createdBy: "ObjectId (ref: users)",
  createdAt: "Date",
  updatedAt: "Date",
  indexes: [
    { candidate: 1 },
    { job: 1 },
    { scheduledTime: 1 },
    { status: 1 },
    { company: 1 }
  ],
  security: {
    encryption: {
      fields: ["feedback", "aiAnalysis", "notes"]
    }
  }
};

// Offer schema
const offerSchema = {
  _id: "ObjectId",
  candidate: "ObjectId (ref: candidates)",
  job: "ObjectId (ref: jobs)",
  company: "ObjectId (ref: companies)",
  compensation: {
    baseSalary: {
      amount: "Number",
      currency: "String",
      period: "String (enum: yearly, monthly, hourly)"
    },
    equity: {
      amount: "Number",
      vestingPeriod: "Number (months)"
    },
    bonus: {
      amount: "Number",
      type: "String (enum: signing, performance, annual)"
    },
    benefits: ["String"]
  },
  startDate: "Date",
  expirationDate: "Date",
  status: "String (enum: draft, pending_approval, approved, sent, accepted, negotiating, declined, expired)",
  approvalWorkflow: [{
    approver: "ObjectId (ref: users)",
    status: "String (enum: pending, approved, rejected)",
    comments: "String",
    timestamp: "Date"
  }],
  documentUrl: "String",
  negotiations: [{
    requestedBy: "String (enum: candidate, company)",
    requestDetails: "String",
    companyResponse: "String",
    status: "String (enum: pending, accepted, rejected)",
    timestamp: "Date"
  }],
  acceptanceDetails: {
    acceptedAt: "Date",
    signedDocumentUrl: "String"
  },
  declineReason: "String",
  notes: "String",
  createdBy: "ObjectId (ref: users)",
  createdAt: "Date",
  updatedAt: "Date",
  indexes: [
    { candidate: 1 },
    { job: 1 },
    { status: 1 },
    { company: 1 }
  ],
  security: {
    encryption: {
      fields: ["compensation", "negotiations", "notes"]
    }
  }
};

// Onboarding schema
const onboardingSchema = {
  _id: "ObjectId",
  candidate: "ObjectId (ref: candidates)",
  job: "ObjectId (ref: jobs)",
  company: "ObjectId (ref: companies)",
  startDate: "Date",
  status: "String (enum: not_started, in_progress, completed)",
  tasks: [{
    title: "String",
    description: "String",
    category: "String (enum: paperwork, equipment, training, introduction, access)",
    assignedTo: "ObjectId (ref: users)",
    dueDate: "Date",
    status: "String (enum: pending, in_progress, completed, blocked)",
    completedAt: "Date",
    notes: "String"
  }],
  documents: [{
    title: "String",
    type: "String (enum: identification, tax, benefits, policies, agreements)",
    status: "String (enum: pending, received, verified)",
    documentUrl: "String",
    submittedAt: "Date"
  }],
  equipment: [{
    type: "String",
    details: "String",
    status: "String (enum: ordered, delivered, setup_complete)"
  }],
  progress: {
    completedTasks: "Number",
    totalTasks: "Number",
    percentComplete: "Number"
  },
  feedback: {
    rating: "Number (1-5)",
    comments: "String",
    submittedAt: "Date"
  },
  notes: "String",
  createdBy: "ObjectId (ref: users)",
  createdAt: "Date",
  updatedAt: "Date",
  indexes: [
    { candidate: 1 },
    { job: 1 },
    { status: 1 },
    { company: 1 },
    { startDate: 1 }
  ]
};

// Company schema
const companySchema = {
  _id: "ObjectId",
  name: "String (required)",
  logo: "String",
  industry: "String",
  size: "String (enum: 1-10, 11-50, 51-200, 201-500, 501-1000, 1001-5000, 5001+)",
  website: "String",
  locations: [{
    name: "String",
    address: "String",
    city: "String",
    state: "String",
    country: "String",
    isPrimary: "Boolean"
  }],
  description: "String",
  culture: {
    values: ["String"],
    mission: "String",
    vision: "String"
  },
  socialMedia: {
    linkedin: "String",
    twitter: "String",
    facebook: "String",
    instagram: "String"
  },
  recruitmentSettings: {
    aiEnabled: "Boolean (default: true)",
    automationLevel: "String (enum: full, partial, minimal)",
    approvalWorkflows: {
      jobPostings: "Boolean",
      offers: "Boolean"
    },
    interviewStages: ["String"],
    customFields: [{
      name: "String",
      type: "String (enum: text, number, date, boolean, select)",
      options: ["String"],
      required: "Boolean",
      appliesTo: "String (enum: candidate, job, interview)"
    }]
  },
  subscription: {
    plan: "String (enum: free, starter, professional, enterprise)",
    startDate: "Date",
    endDate: "Date",
    status: "String (enum: active, trial, expired, cancelled)"
  },
  createdAt: "Date",
  updatedAt: "Date",
  indexes: [
    { name: 1 },
    { industry: 1 }
  ]
};

// Analytics schema
const analyticsSchema = {
  _id: "ObjectId",
  company: "ObjectId (ref: companies)",
  period: {
    start: "Date",
    end: "Date"
  },
  recruitment: {
    jobsPosted: "Number",
    applicationsReceived: "Number",
    candidatesSourced: "Number",
    interviewsScheduled: "Number",
    offersExtended: "Number",
    offersAccepted: "Number",
    newHires: "Number",
    timeToFill: {
      average: "Number (days)",
      byDepartment: [{
        department: "String",
        days: "Number"
      }]
    },
    costPerHire: "Number",
    sourceEffectiveness: [{
      source: "String",
      candidates: "Number",
      hires: "Number",
      conversionRate: "Number"
    }]
  },
  automation: {
    candidatesAutoSourced: "Number",
    resumesAutoScreened: "Number",
    interviewsAutoScheduled: "Number",
    timesSaved: "Number (hours)",
    costsSaved: "Number"
  },
  aiPerformance: {
    matchAccuracy: "Number (percentage)",
    screeningAccuracy: "Number (percentage)",
    interviewInsightAccuracy: "Number (percentage)"
  },
  createdAt: "Date",
  updatedAt: "Date",
  indexes: [
    { company: 1 },
    { "period.start": 1, "period.end": 1 }
  ]
};

// Export the schemas
module.exports = {
  dbConfig,
  userSchema,
  candidateSchema,
  jobSchema,
  interviewSchema,
  offerSchema,
  onboardingSchema,
  companySchema,
  analyticsSchema
};
