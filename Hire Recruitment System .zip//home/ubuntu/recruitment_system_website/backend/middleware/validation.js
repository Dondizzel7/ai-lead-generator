const Joi = require('joi');

/**
 * Validation middleware for user registration
 * @param {Object} data - Registration data to validate
 * @returns {Object} - Validation result
 */
const validateRegistration = (data) => {
  const schema = Joi.object({
    email: Joi.string().email().required().messages({
      'string.email': 'Please provide a valid email address',
      'any.required': 'Email is required'
    }),
    password: Joi.string().min(8).required().messages({
      'string.min': 'Password must be at least 8 characters long',
      'any.required': 'Password is required'
    }),
    firstName: Joi.string().required().messages({
      'any.required': 'First name is required'
    }),
    lastName: Joi.string().required().messages({
      'any.required': 'Last name is required'
    }),
    role: Joi.string().valid('admin', 'recruiter', 'hiring_manager', 'interviewer').default('recruiter'),
    company: Joi.string().required().messages({
      'any.required': 'Company ID is required'
    }),
    phone: Joi.string(),
    department: Joi.string(),
    position: Joi.string()
  });

  return schema.validate(data);
};

/**
 * Validation middleware for user login
 * @param {Object} data - Login data to validate
 * @returns {Object} - Validation result
 */
const validateLogin = (data) => {
  const schema = Joi.object({
    email: Joi.string().email().required().messages({
      'string.email': 'Please provide a valid email address',
      'any.required': 'Email is required'
    }),
    password: Joi.string().required().messages({
      'any.required': 'Password is required'
    })
  });

  return schema.validate(data);
};

/**
 * Validation middleware for candidate creation
 * @param {Object} data - Candidate data to validate
 * @returns {Object} - Validation result
 */
const validateCandidate = (data) => {
  const schema = Joi.object({
    firstName: Joi.string().required().messages({
      'any.required': 'First name is required'
    }),
    lastName: Joi.string().required().messages({
      'any.required': 'Last name is required'
    }),
    email: Joi.string().email().required().messages({
      'string.email': 'Please provide a valid email address',
      'any.required': 'Email is required'
    }),
    phone: Joi.string(),
    location: Joi.object({
      city: Joi.string(),
      state: Joi.string(),
      country: Joi.string(),
      remote: Joi.boolean()
    }),
    resumeUrl: Joi.string(),
    linkedinUrl: Joi.string(),
    githubUrl: Joi.string(),
    portfolioUrl: Joi.string(),
    source: Joi.string().valid('linkedin', 'github', 'stackoverflow', 'referral', 'application', 'other'),
    skills: Joi.array().items(
      Joi.object({
        name: Joi.string().required(),
        level: Joi.number().min(1).max(5),
        yearsOfExperience: Joi.number(),
        verified: Joi.boolean()
      })
    ),
    experience: Joi.array().items(
      Joi.object({
        company: Joi.string().required(),
        title: Joi.string().required(),
        location: Joi.string(),
        startDate: Joi.date().required(),
        endDate: Joi.date(),
        current: Joi.boolean(),
        description: Joi.string(),
        verified: Joi.boolean()
      })
    ),
    education: Joi.array().items(
      Joi.object({
        institution: Joi.string().required(),
        degree: Joi.string().required(),
        field: Joi.string(),
        startDate: Joi.date(),
        endDate: Joi.date(),
        verified: Joi.boolean()
      })
    ),
    status: Joi.string().valid('new', 'screening', 'interviewing', 'offer', 'hired', 'rejected', 'archived'),
    notes: Joi.array().items(
      Joi.object({
        content: Joi.string().required(),
        author: Joi.string().required(),
        createdAt: Joi.date()
      })
    ),
    tags: Joi.array().items(Joi.string()),
    company: Joi.string().required().messages({
      'any.required': 'Company ID is required'
    })
  });

  return schema.validate(data);
};

/**
 * Validation middleware for job creation
 * @param {Object} data - Job data to validate
 * @returns {Object} - Validation result
 */
const validateJob = (data) => {
  const schema = Joi.object({
    title: Joi.string().required().messages({
      'any.required': 'Job title is required'
    }),
    company: Joi.string().required().messages({
      'any.required': 'Company ID is required'
    }),
    department: Joi.string(),
    location: Joi.object({
      city: Joi.string(),
      state: Joi.string(),
      country: Joi.string(),
      remote: Joi.boolean()
    }),
    type: Joi.string().valid('full_time', 'part_time', 'contract', 'temporary', 'internship'),
    description: Joi.string().required().messages({
      'any.required': 'Job description is required'
    }),
    responsibilities: Joi.array().items(Joi.string()),
    requirements: Joi.object({
      essential: Joi.array().items(Joi.string()),
      preferred: Joi.array().items(Joi.string())
    }),
    skills: Joi.array().items(
      Joi.object({
        name: Joi.string().required(),
        level: Joi.number().min(1).max(5),
        importance: Joi.number().min(1).max(5)
      })
    ),
    experience: Joi.object({
      minYears: Joi.number(),
      level: Joi.string().valid('entry', 'mid', 'senior', 'executive')
    }),
    education: Joi.object({
      degree: Joi.string(),
      field: Joi.string(),
      required: Joi.boolean()
    }),
    salary: Joi.object({
      min: Joi.number(),
      max: Joi.number(),
      currency: Joi.string(),
      visible: Joi.boolean()
    }),
    benefits: Joi.array().items(Joi.string()),
    status: Joi.string().valid('draft', 'open', 'paused', 'closed', 'filled'),
    applicationDeadline: Joi.date(),
    hiringManager: Joi.string(),
    recruiters: Joi.array().items(Joi.string()),
    interviewProcess: Joi.array().items(
      Joi.object({
        stage: Joi.string().required(),
        description: Joi.string(),
        interviewers: Joi.array().items(Joi.string())
      })
    ),
    aiSettings: Joi.object({
      autoSourceCandidates: Joi.boolean(),
      autoScreenResumes: Joi.boolean(),
      autoScheduleInterviews: Joi.boolean(),
      matchThreshold: Joi.number().min(0).max(100)
    })
  });

  return schema.validate(data);
};

/**
 * Validation middleware for interview creation
 * @param {Object} data - Interview data to validate
 * @returns {Object} - Validation result
 */
const validateInterview = (data) => {
  const schema = Joi.object({
    candidate: Joi.string().required().messages({
      'any.required': 'Candidate ID is required'
    }),
    job: Joi.string().required().messages({
      'any.required': 'Job ID is required'
    }),
    company: Joi.string().required().messages({
      'any.required': 'Company ID is required'
    }),
    type: Joi.string().valid('phone_screen', 'technical', 'behavioral', 'case_study', 'panel', 'final').required(),
    scheduledTime: Joi.object({
      start: Joi.date().required(),
      end: Joi.date().required()
    }).required(),
    location: Joi.object({
      type: Joi.string().valid('in_person', 'video', 'phone').required(),
      details: Joi.string()
    }),
    interviewers: Joi.array().items(
      Joi.object({
        user: Joi.string().required(),
        role: Joi.string(),
        confirmed: Joi.boolean()
      })
    ).min(1).required(),
    questions: Joi.array().items(
      Joi.object({
        text: Joi.string().required(),
        type: Joi.string().valid('technical', 'behavioral', 'situational'),
        expectedAnswer: Joi.string(),
        importance: Joi.number().min(1).max(5)
      })
    ),
    status: Joi.string().valid('scheduled', 'completed', 'cancelled', 'no_show', 'rescheduled'),
    notes: Joi.string()
  });

  return schema.validate(data);
};

module.exports = {
  validateRegistration,
  validateLogin,
  validateCandidate,
  validateJob,
  validateInterview
};
