const jwt = require('jsonwebtoken');
const User = require('../../models/user.model');

/**
 * Authentication middleware to protect routes
 * Verifies JWT token and attaches user to request object
 */
module.exports = async function(req, res, next) {
  try {
    // Get token from header
    const token = req.header('x-auth-token');
    
    // Check if token exists
    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'No authentication token, access denied'
      });
    }
    
    // Verify token
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      
      // Attach user to request
      req.user = decoded;
      
      // Check if user still exists and is active
      const user = await User.findById(decoded.id).select('isActive');
      
      if (!user) {
        return res.status(401).json({
          success: false,
          message: 'User does not exist'
        });
      }
      
      if (!user.isActive) {
        return res.status(401).json({
          success: false,
          message: 'User account is inactive'
        });
      }
      
      next();
    } catch (error) {
      return res.status(401).json({
        success: false,
        message: 'Token is invalid or expired'
      });
    }
  } catch (error) {
    console.error('Authentication middleware error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error in authentication middleware'
    });
  }
};
